import { Injectable, signal, computed } from '@angular/core';

export interface ReservationsListingFilters {
  search: string;
  status: string;
  warehouse: string;
  zone: string;
  period: string;
}

@Injectable({
  providedIn: 'root'
})
export class ReservationsListingFiltersService {
  // Signals for filter state
  private _search = signal<string>('');
  private _status = signal<string>('');
  private _warehouse = signal<string>('');
  private _zone = signal<string>('');
  private _period = signal<string>('');

  // Computed signal that combines all filters
  filters = computed<ReservationsListingFilters>(() => ({
    search: this._search(),
    status: this._status(),
    warehouse: this._warehouse(),
    zone: this._zone(),
    period: this._period()
  }));

  // Individual filter getters
  get search() { return this._search.asReadonly(); }
  get status() { return this._status.asReadonly(); }
  get warehouse() { return this._warehouse.asReadonly(); }
  get zone() { return this._zone.asReadonly(); }
  get period() { return this._period.asReadonly(); }

  // Filter setters
  setSearch(search: string): void {
    this._search.set(search);
  }

  setStatus(status: string): void {
    this._status.set(status);
  }

  setWarehouse(warehouse: string): void {
    this._warehouse.set(warehouse);
  }

  setZone(zone: string): void {
    this._zone.set(zone);
  }

  setPeriod(period: string): void {
    this._period.set(period);
  }

  // Reset all filters
  resetFilters(): void {
    this._search.set('');
    this._status.set('');
    this._warehouse.set('');
    this._zone.set('');
    this._period.set('');
  }

  // Check if any filters are active
  hasActiveFilters = computed<boolean>(() => {
    const filters = this.filters();
    return !!(filters.search || filters.status || filters.warehouse || filters.zone || filters.period);
  });
}