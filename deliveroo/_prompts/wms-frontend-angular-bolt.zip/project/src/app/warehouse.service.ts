import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs/operators';
import { 
  Warehouse, 
  Dock, 
  DockAppointment, 
  InventoryItem, 
  InventoryOverview, 
  StorageRequest 
} from '../app/types/interfaces';

@Injectable({
  providedIn: 'root'
})
export class WarehouseService {
  private mockDocks: Dock[] = [
    {
      id: 1,
      warehouseId: 1,
      name: 'Dock 1',
      type: 'receiving',
      status: 'available',
      appointments: []
    },
    {
      id: 2,
      warehouseId: 1,
      name: 'Dock 2',
      type: 'shipping',
      status: 'occupied',
      currentTruck: {
        id: 1,
        licensePlate: 'ABC-123',
        carrierId: 1,
        carrierName: 'Swift Transport',
        driverId: 1,
        driverName: 'John Driver',
        driverPhone: '+1-555-0123',
        truckType: 'Semi-trailer',
        capacity: 40,
        capacityUnit: 'tons'
      },
      appointments: []
    }
  ];

  private mockInventoryItems: InventoryItem[] = [
    {
      id: 1,
      sku: 'ELEC-001',
      name: 'Electronics Package',
      description: 'Consumer electronics shipment',
      category: 'Electronics',
      quantity: 100,
      unit: 'pieces',
      location: 'Zone A-1-R1-S3',
      zoneId: 1,
      zoneName: 'Zone A - Standard',
      shelfId: 1,
      shelfLocation: 'A-1-R1-S3',
      weight: 500,
      volume: 25,
      value: 15000,
      currency: 'USD',
      status: 'available',
      lastUpdated: new Date(),
      customerId: 1,
      customerName: 'ABC Corp'
    }
  ];

  private mockStorageRequests: StorageRequest[] = [
    {
      id: 1,
      customerId: 1,
      customerName: 'ABC Corp',
      warehouseId: 1,
      requestedEntryDate: new Date('2025-01-15'),
      requestedExitDate: new Date('2025-02-15'),
      status: 'pending',
      cargoDetails: {
        description: 'Electronics equipment',
        weight: 500,
        volume: 25,
        requiresRefrigeration: false,
        requiresFreezing: false,
        isHazardous: false,
        containsPerishables: false,
        estimatedValue: 15000,
        currency: 'USD'
      },
      reservations: [],
      createdAt: new Date(),
      updatedAt: new Date()
    }
  ];

  private mockWarehouses: Warehouse[] = [
    {
      id: 1,
      name: 'Main Warehouse',
      description: 'Primary distribution center',
      location: {
        id: 1,
        address: '123 Industrial Blvd',
        city: 'Chicago',
        postalCode: '60601',
        country: 'USA'
      },
      zones: [
        {
          id: 1,
          warehouseId: 1,
          name: 'Zone A - Standard',
          zoneType: 'standard',
          aisles: [],
          capacity: {
            id: 1,
            entityType: 'ZONE',
            entityId: 1,
            value: 10000,
            unit: 'cubic_meters',
            usedCapacity: 7500,
            availableCapacity: 2500,
            utilizationPercentage: 75
          }
        }
      ],
      capacity: {
        id: 1,
        entityType: 'WAREHOUSE',
        entityId: 1,
        value: 18000,
        unit: 'cubic_meters',
        usedCapacity: 12200,
        availableCapacity: 5800,
        utilizationPercentage: 68
      },
      isActive: true
    }
  ];

  getDocks(): Observable<Dock[]> {
    return of(this.mockDocks).pipe(delay(300));
  }

  getDock(id: number): Observable<Dock | undefined> {
    const dock = this.mockDocks.find(d => d.id === id);
    return of(dock).pipe(delay(200));
  }

  getRecentDockActivity(): Observable<any[]> {
    const mockActivity = [
      {
        type: 'arrival',
        description: 'Truck ABC-123 arrived at Dock 2',
        timestamp: new Date(),
        dock: 'Dock 2',
        carrier: 'Swift Transport'
      }
    ];
    return of(mockActivity).pipe(delay(200));
  }

  getInventoryItems(): Observable<InventoryItem[]> {
    return of(this.mockInventoryItems).pipe(delay(300));
  }

  getInventoryOverview(): Observable<InventoryOverview> {
    const overview: InventoryOverview = {
      totalItems: 1250,
      totalValue: 2500000,
      lowStockItems: 15,
      expiringSoonItems: 8,
      damagedItems: 3,
      categoryBreakdown: [
        { category: 'Electronics', count: 450, value: 1200000 },
        { category: 'Clothing', count: 300, value: 450000 },
        { category: 'Food', count: 500, value: 850000 }
      ],
      zoneUtilization: [
        { zoneId: 1, zoneName: 'Zone A', utilization: 75, itemCount: 450 },
        { zoneId: 2, zoneName: 'Zone B', utilization: 64, itemCount: 300 }
      ]
    };
    return of(overview).pipe(delay(300));
  }

  getWarehouses(): Observable<Warehouse[]> {
    return of(this.mockWarehouses).pipe(delay(300));
  }

  getStorageRequests(): Observable<StorageRequest[]> {
    return of(this.mockStorageRequests).pipe(delay(300));
  }

  updateStorageRequestStatus(requestId: number, status: string, employeeId: number): Observable<void> {
    const request = this.mockStorageRequests.find(r => r.id === requestId);
    if (request) {
      request.status = status as any;
      request.decisionEmployeeId = employeeId;
      request.decisionDate = new Date();
    }
    return of(void 0).pipe(delay(500));
  }
}