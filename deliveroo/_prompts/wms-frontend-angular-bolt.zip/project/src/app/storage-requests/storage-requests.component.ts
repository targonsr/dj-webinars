import { Component, OnInit, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { WarehouseService } from '../warehouse.service';
import { AuthService } from '../auth/auth.service';
import { StorageRequest } from '../types/interfaces';
import { StorageRequestsFiltersService } from './storage-requests-listing-filters.service';
import { StorageRequestsListingFiltersComponent } from './storage-requests-listing-filters.component';
import { StorageRequestsListingComponent } from './storage-requests-listing.component';
import { StorageRequestsFormNewRequestComponent } from './storage-requests-form-new-request.component';
import { LucideAngularModule, Plus } from 'lucide-angular';

@Component({
  selector: 'app-storage-requests',
  standalone: true,
  imports: [
    CommonModule, 
    RouterLink, 
    LucideAngularModule,
    StorageRequestsListingFiltersComponent,
    StorageRequestsListingComponent,
    StorageRequestsFormNewRequestComponent
  ],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex justify-between items-center">
        <div>
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Storage Requests</h1>
          <p class="text-gray-600 dark:text-gray-400">Manage storage requests and reservations</p>
        </div>
        <button (click)="showNewRequestModal = true" 
                class="btn btn-primary">
          <lucide-icon [img]="PlusIcon" size="18" class="mr-2"></lucide-icon>
          New Request
        </button>
      </div>

      <!-- Filters Component -->
      <app-storage-requests-listing-filters />

      <!-- Listing Component -->
      <app-storage-requests-listing 
        [requests]="filteredRequests"
        [canApprove]="canApprove()"
        [hasActiveFilters]="filtersService.hasActiveFilters()"
        (approveRequest)="approveRequest($event)"
        (rejectRequest)="rejectRequest($event)" />

      <!-- New Request Modal -->
      <app-storage-requests-form-new-request
        [showModal]="showNewRequestModal"
        (modalClosed)="showNewRequestModal = false"
        (requestSubmitted)="onRequestSubmitted($event)" />
    </div>
  `
})
export class StorageRequestsComponent implements OnInit {
  storageRequests: StorageRequest[] = [];
  filteredRequests: StorageRequest[] = [];
  showNewRequestModal = false;

  // Lucide icons
  PlusIcon = Plus;

  constructor(
    private warehouseService: WarehouseService,
    private authService: AuthService,
    public filtersService: StorageRequestsFiltersService
  ) {
    // Effect to automatically filter requests when filters change
    effect(() => {
      this.applyFilters();
    });
  }

  ngOnInit(): void {
    this.loadStorageRequests();
  }

  loadStorageRequests(): void {
    this.warehouseService.getStorageRequests().subscribe(requests => {
      this.storageRequests = requests;
      this.applyFilters();
    });
  }

  applyFilters(): void {
    const filters = this.filtersService.filters();
    
    this.filteredRequests = this.storageRequests.filter(request => {
      // Status filter
      if (filters.status && request.status !== filters.status) {
        return false;
      }

      // Customer filter
      if (filters.customer && !request.customerName.toLowerCase().includes(filters.customer.toLowerCase())) {
        return false;
      }

      // Date from filter
      if (filters.dateFrom) {
        const dateFrom = new Date(filters.dateFrom);
        if (new Date(request.requestedEntryDate) < dateFrom) {
          return false;
        }
      }

      // Date to filter
      if (filters.dateTo) {
        const dateTo = new Date(filters.dateTo);
        if (new Date(request.requestedEntryDate) > dateTo) {
          return false;
        }
      }

      return true;
    });
  }

  canApprove(): boolean {
    return this.authService.hasRole('Warehouse Manager') || this.authService.hasRole('Logistics Coordinator');
  }

  approveRequest(requestId: number): void {
    const currentUser = this.authService.currentUserValue;
    if (!currentUser) return;

    this.warehouseService.updateStorageRequestStatus(requestId, 'accepted', currentUser.id)
      .subscribe(() => {
        this.loadStorageRequests();
      });
  }

  rejectRequest(requestId: number): void {
    const currentUser = this.authService.currentUserValue;
    if (!currentUser) return;

    this.warehouseService.updateStorageRequestStatus(requestId, 'rejected', currentUser.id)
      .subscribe(() => {
        this.loadStorageRequests();
      });
  }

  onRequestSubmitted(requestData: any): void {
    // Add the new request to the list
    this.storageRequests.unshift(requestData);
    this.applyFilters();
  }
}