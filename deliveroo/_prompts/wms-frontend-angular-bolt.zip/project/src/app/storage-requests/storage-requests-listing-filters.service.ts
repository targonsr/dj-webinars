import { Injectable, signal, computed } from '@angular/core';

export interface StorageRequestFilters {
  status: string;
  customer: string;
  dateFrom: string;
  dateTo: string;
}

@Injectable({
  providedIn: 'root'
})
export class StorageRequestsFiltersService {
  // Signals for filter state
  private _status = signal<string>('');
  private _customer = signal<string>('');
  private _dateFrom = signal<string>('');
  private _dateTo = signal<string>('');

  // Computed signal that combines all filters
  filters = computed<StorageRequestFilters>(() => ({
    status: this._status(),
    customer: this._customer(),
    dateFrom: this._dateFrom(),
    dateTo: this._dateTo()
  }));

  // Individual filter getters
  get status() { return this._status.asReadonly(); }
  get customer() { return this._customer.asReadonly(); }
  get dateFrom() { return this._dateFrom.asReadonly(); }
  get dateTo() { return this._dateTo.asReadonly(); }

  // Filter setters
  setStatus(status: string): void {
    this._status.set(status);
  }

  setCustomer(customer: string): void {
    this._customer.set(customer);
  }

  setDateFrom(dateFrom: string): void {
    this._dateFrom.set(dateFrom);
  }

  setDateTo(dateTo: string): void {
    this._dateTo.set(dateTo);
  }

  // Reset all filters
  resetFilters(): void {
    this._status.set('');
    this._customer.set('');
    this._dateFrom.set('');
    this._dateTo.set('');
  }

  // Check if any filters are active
  hasActiveFilters = computed<boolean>(() => {
    const filters = this.filters();
    return !!(filters.status || filters.customer || filters.dateFrom || filters.dateTo);
  });
}