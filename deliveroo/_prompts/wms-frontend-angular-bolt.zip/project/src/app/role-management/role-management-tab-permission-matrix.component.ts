import { Component, input, output } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Role, Permission } from '../employees/employees.interfaces';
import { LucideAngularModule } from 'lucide-angular';

@Component({
  selector: 'app-role-management-tab-permission-matrix',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <div class="p-6">
      <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-6">Permission Matrix</h3>
      
      <div class="overflow-x-auto">
        <table class="min-w-full border border-gray-200 dark:border-dark-700">
          <thead class="bg-gray-50 dark:bg-dark-800">
            <tr>
              <th class="px-4 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider border-r border-gray-200 dark:border-dark-700">
                Role / Permission
              </th>
              <th *ngFor="let permission of allPermissions()" 
                  class="px-4 py-3 text-center text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider border-r border-gray-200 dark:border-dark-700">
                {{ permission.name }}
              </th>
            </tr>
          </thead>
          <tbody class="bg-white dark:bg-dark-800">
            <tr *ngFor="let role of roles()" class="border-b border-gray-200 dark:border-dark-700">
              <td class="px-4 py-3 font-medium text-gray-900 dark:text-white border-r border-gray-200 dark:border-dark-700">
                {{ role.name }}
              </td>
              <td *ngFor="let permission of allPermissions()" 
                  class="px-4 py-3 text-center border-r border-gray-200 dark:border-dark-700">
                <input type="checkbox" 
                       [checked]="hasPermission(role, permission)"
                       (change)="onTogglePermission(role, permission, $event)"
                       class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded">
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  `
})
export class RoleManagementTabPermissionMatrixComponent {
  // Signal-based inputs
  roles = input<Role[]>([]);
  allPermissions = input<Permission[]>([]);

  // Outputs
  togglePermission = output<{role: Role, permission: Permission, checked: boolean}>();

  onTogglePermission(role: Role, permission: Permission, event: any): void {
    this.togglePermission.emit({
      role,
      permission,
      checked: event.target.checked
    });
  }

  hasPermission(role: Role, permission: Permission): boolean {
    return role.permissions.some(p => p.id === permission.id);
  }
}