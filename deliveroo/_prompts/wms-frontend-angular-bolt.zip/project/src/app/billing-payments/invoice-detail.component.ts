import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ActivatedRoute, RouterLink } from '@angular/router';
import { BillingService } from './billing.service';
import { Invoice } from './billing.interfaces';
import { LucideAngularModule, ArrowLeft, FileText, Calendar, DollarSign, User, Download, Send, Edit } from 'lucide-angular';

@Component({
  selector: 'app-invoice-detail',
  standalone: true,
  imports: [CommonModule, RouterLink, LucideAngularModule],
  template: `
    <div class="space-y-6" *ngIf="invoice">
      <!-- Header -->
      <div class="flex items-center justify-between">
        <div class="flex items-center space-x-4">
          <button routerLink="/billing-payments" class="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <lucide-icon [img]="ArrowLeftIcon" size="20"></lucide-icon>
          </button>
          <div>
            <h1 class="text-2xl font-bold text-gray-900 dark:text-white">{{ invoice.invoiceNumber }}</h1>
            <p class="text-gray-600 dark:text-gray-400">Invoice Details</p>
          </div>
          <span [class]="getStatusClass(invoice.status)" 
                class="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium">
            {{ invoice.status | titlecase }}
          </span>
        </div>
        <div class="flex space-x-3">
          <button class="btn btn-secondary">
            <lucide-icon [img]="EditIcon" size="18" class="mr-2"></lucide-icon>
            Edit
          </button>
          <button class="btn btn-secondary">
            <lucide-icon [img]="SendIcon" size="18" class="mr-2"></lucide-icon>
            Send
          </button>
          <button class="btn btn-primary">
            <lucide-icon [img]="DownloadIcon" size="18" class="mr-2"></lucide-icon>
            Download PDF
          </button>
        </div>
      </div>

      <!-- Invoice Details Card -->
      <div class="card p-8">
        <!-- Invoice Header -->
        <div class="flex justify-between items-start mb-8">
          <div>
            <h2 class="text-3xl font-bold text-gray-900 dark:text-white mb-2">INVOICE</h2>
            <div class="space-y-1">
              <p class="text-sm text-gray-600 dark:text-gray-400">Invoice Number: <span class="font-medium text-gray-900 dark:text-white">{{ invoice.invoiceNumber }}</span></p>
              <p class="text-sm text-gray-600 dark:text-gray-400">Issue Date: <span class="font-medium text-gray-900 dark:text-white">{{ invoice.issueDate | date:'MMM d, y' }}</span></p>
              <p class="text-sm text-gray-600 dark:text-gray-400">Due Date: <span class="font-medium text-gray-900 dark:text-white">{{ invoice.dueDate | date:'MMM d, y' }}</span></p>
            </div>
          </div>
          <div class="text-right">
            <div class="text-4xl font-bold text-primary-600">{{ invoice.amount | currency:'USD':'symbol':'1.2-2' }}</div>
            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">Total Amount</p>
          </div>
        </div>

        <!-- Bill To Section -->
        <div class="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
          <div>
            <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-3">From:</h3>
            <div class="space-y-1">
              <p class="font-medium text-gray-900 dark:text-white">Warehouse Management System</p>
              <p class="text-sm text-gray-600 dark:text-gray-400">123 Industrial Blvd</p>
              <p class="text-sm text-gray-600 dark:text-gray-400">Chicago, IL 60601</p>
              <p class="text-sm text-gray-600 dark:text-gray-400">Phone: +1-555-0100</p>
              <p class="text-sm text-gray-600 dark:text-gray-400">Email: billing{{'@'}}wms.com</p>
            </div>
          </div>
          <div>
            <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-3">Bill To:</h3>
            <div class="space-y-1">
              <a [routerLink]="['/customers', invoice.customerId]" 
                 class="font-medium text-primary-600 hover:text-primary-500">
                {{ invoice.customerName }}
              </a>
              <p class="text-sm text-gray-600 dark:text-gray-400">Customer ID: {{ invoice.customerId }}</p>
              <p class="text-sm text-gray-600 dark:text-gray-400">123 Business Ave</p>
              <p class="text-sm text-gray-600 dark:text-gray-400">Business City, BC 12345</p>
              <p class="text-sm text-gray-600 dark:text-gray-400">contact{{'@'}}{{ invoice.customerName.toLowerCase().replace(' ', '') }}.com</p>
            </div>
          </div>
        </div>

        <!-- Invoice Items -->
        <div class="mb-8">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Invoice Items</h3>
          <div class="overflow-x-auto">
            <table class="min-w-full divide-y divide-gray-200 dark:divide-dark-700">
              <thead class="bg-gray-50 dark:bg-dark-800">
                <tr>
                  <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Description
                  </th>
                  <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Quantity
                  </th>
                  <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Unit Price
                  </th>
                  <th class="px-6 py-3 text-right text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                    Total
                  </th>
                </tr>
              </thead>
              <tbody class="bg-white dark:bg-dark-800 divide-y divide-gray-200 dark:divide-dark-700">
                <tr *ngFor="let item of mockInvoiceItems">
                  <td class="px-6 py-4 text-sm text-gray-900 dark:text-white">{{ item.description }}</td>
                  <td class="px-6 py-4 text-sm text-gray-900 dark:text-white text-right">{{ item.quantity }}</td>
                  <td class="px-6 py-4 text-sm text-gray-900 dark:text-white text-right">{{ item.unitPrice | currency:'USD':'symbol':'1.2-2' }}</td>
                  <td class="px-6 py-4 text-sm text-gray-900 dark:text-white text-right">{{ item.totalPrice | currency:'USD':'symbol':'1.2-2' }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>

        <!-- Invoice Summary -->
        <div class="flex justify-end">
          <div class="w-64">
            <div class="space-y-2">
              <div class="flex justify-between">
                <span class="text-sm text-gray-600 dark:text-gray-400">Subtotal:</span>
                <span class="text-sm font-medium text-gray-900 dark:text-white">{{ getSubtotal() | currency:'USD':'symbol':'1.2-2' }}</span>
              </div>
              <div class="flex justify-between">
                <span class="text-sm text-gray-600 dark:text-gray-400">Tax (8.5%):</span>
                <span class="text-sm font-medium text-gray-900 dark:text-white">{{ getTax() | currency:'USD':'symbol':'1.2-2' }}</span>
              </div>
              <div class="border-t border-gray-200 dark:border-dark-600 pt-2">
                <div class="flex justify-between">
                  <span class="text-lg font-medium text-gray-900 dark:text-white">Total:</span>
                  <span class="text-lg font-bold text-gray-900 dark:text-white">{{ invoice.amount | currency:'USD':'symbol':'1.2-2' }}</span>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Payment Information -->
        <div class="mt-8 pt-8 border-t border-gray-200 dark:border-dark-600">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Payment Information</h3>
          <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <h4 class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Payment Terms</h4>
              <p class="text-sm text-gray-600 dark:text-gray-400">Net 30 days</p>
            </div>
            <div>
              <h4 class="text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">Payment Methods</h4>
              <div class="text-sm text-gray-600 dark:text-gray-400">
                <p>Bank Transfer: Account #123-456-789</p>
                <p>Check: Payable to "WMS Inc."</p>
              </div>
            </div>
          </div>
        </div>

        <!-- Notes -->
        <div class="mt-8 pt-8 border-t border-gray-200 dark:border-dark-600">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-4">Notes</h3>
          <p class="text-sm text-gray-600 dark:text-gray-400">
            Thank you for your business! Please remit payment within 30 days of the invoice date. 
            For any questions regarding this invoice, please contact our billing department at billing{{'@'}}wms.com.
          </p>
        </div>
      </div>
    </div>

    <div *ngIf="!invoice" class="flex items-center justify-center h-64">
      <div class="text-center">
        <lucide-icon [img]="FileTextIcon" size="48" class="mx-auto text-gray-400 mb-4"></lucide-icon>
        <h3 class="mt-2 text-sm font-medium text-gray-900 dark:text-white">Invoice not found</h3>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">The requested invoice could not be found.</p>
      </div>
    </div>
  `
})
export class InvoiceDetailComponent implements OnInit {
  invoice: Invoice | null = null;
  invoiceId: number = 0;

  // Lucide icons
  ArrowLeftIcon = ArrowLeft;
  FileTextIcon = FileText;
  CalendarIcon = Calendar;
  DollarSignIcon = DollarSign;
  UserIcon = User;
  DownloadIcon = Download;
  SendIcon = Send;
  EditIcon = Edit;

  mockInvoiceItems = [
    {
      description: 'Storage Services - Zone A (January 2025)',
      quantity: 1,
      unitPrice: 12000,
      totalPrice: 12000
    },
    {
      description: 'Handling Services - Cargo Processing',
      quantity: 5,
      unitPrice: 500,
      totalPrice: 2500
    },
    {
      description: 'Additional Security Services',
      quantity: 1,
      unitPrice: 300,
      totalPrice: 300
    }
  ];

  constructor(
    private route: ActivatedRoute,
    private billingService: BillingService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe(params => {
      this.invoiceId = parseInt(params['id']);
      this.loadInvoiceDetails();
    });
  }

  loadInvoiceDetails(): void {
    this.billingService.getInvoice(this.invoiceId).subscribe(invoice => {
      this.invoice = invoice || null;
    });
  }

  getSubtotal(): number {
    return this.mockInvoiceItems.reduce((sum, item) => sum + item.totalPrice, 0);
  }

  getTax(): number {
    return this.getSubtotal() * 0.085; // 8.5% tax
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'paid': return 'bg-success-100 text-success-800';
      case 'sent': return 'bg-primary-100 text-primary-800';
      case 'overdue': return 'bg-error-100 text-error-800';
      case 'draft': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }
}