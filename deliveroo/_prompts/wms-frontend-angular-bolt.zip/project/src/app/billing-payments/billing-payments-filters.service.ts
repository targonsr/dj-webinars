import { Injectable, signal, computed } from '@angular/core';

export interface BillingPaymentsFilters {
  search: string;
  status: string;
  customer: string;
  dateFrom: string;
  dateTo: string;
}

@Injectable({
  providedIn: 'root'
})
export class BillingPaymentsFiltersService {
  // Signals for filter state
  private _search = signal<string>('');
  private _status = signal<string>('');
  private _customer = signal<string>('');
  private _dateFrom = signal<string>('');
  private _dateTo = signal<string>('');

  // Computed signal that combines all filters
  filters = computed<BillingPaymentsFilters>(() => ({
    search: this._search(),
    status: this._status(),
    customer: this._customer(),
    dateFrom: this._dateFrom(),
    dateTo: this._dateTo()
  }));

  // Individual filter getters
  get search() { return this._search.asReadonly(); }
  get status() { return this._status.asReadonly(); }
  get customer() { return this._customer.asReadonly(); }
  get dateFrom() { return this._dateFrom.asReadonly(); }
  get dateTo() { return this._dateTo.asReadonly(); }

  // Filter setters
  setSearch(search: string): void {
    this._search.set(search);
  }

  setStatus(status: string): void {
    this._status.set(status);
  }

  setCustomer(customer: string): void {
    this._customer.set(customer);
  }

  setDateFrom(dateFrom: string): void {
    this._dateFrom.set(dateFrom);
  }

  setDateTo(dateTo: string): void {
    this._dateTo.set(dateTo);
  }

  // Reset all filters
  resetFilters(): void {
    this._search.set('');
    this._status.set('');
    this._customer.set('');
    this._dateFrom.set('');
    this._dateTo.set('');
  }

  // Check if any filters are active
  hasActiveFilters = computed<boolean>(() => {
    const filters = this.filters();
    return !!(filters.search || filters.status || filters.customer || filters.dateFrom || filters.dateTo);
  });
}