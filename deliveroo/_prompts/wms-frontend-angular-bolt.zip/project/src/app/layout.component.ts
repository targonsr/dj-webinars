import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterOutlet, RouterLink, Router, NavigationEnd } from '@angular/router';
import { AuthService } from './auth/auth.service';
import { NotificationService } from './notifications/notification.service';
import { UserProfile } from './types/interfaces';
import { LucideAngularModule, SquareChevronLeft, SquareChevronRight, Bell, LogOut, BarChart3, Package, FileText, MapPin, Truck, Users, CreditCard, Home, Calendar, UserCheck, Settings, Shield, Cog } from 'lucide-angular';
import { filter } from 'rxjs/operators';

@Component({
  selector: 'app-layout',
  standalone: true,
  imports: [CommonModule, RouterOutlet, RouterLink, 
            LucideAngularModule],
  template: `
    <div class="min-h-screen bg-gray-50 dark:bg-dark-900">
      <!-- Sidebar -->
      <div class="fixed inset-y-0 left-0 z-50 bg-white dark:bg-dark-800 shadow-lg transition-all duration-300 ease-in-out"
           [class.w-64]="!sidebarCollapsed"
           [class.w-16]="sidebarCollapsed">
        <!-- Logo -->
        <div class="flex items-center h-16 px-4 border-b border-gray-200 dark:border-dark-700"
             [class.justify-center]="sidebarCollapsed"
             [class.justify-between]="!sidebarCollapsed">
          <a routerLink="/dashboard" class="flex items-center hover:opacity-80 transition-opacity">
            <div class="h-8 w-8 bg-primary-600 rounded-lg flex items-center justify-center">
              <svg class="h-5 w-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4" />
              </svg>
            </div>
            <span *ngIf="!sidebarCollapsed" class="ml-2 text-lg font-semibold text-gray-900 dark:text-white">WMS</span>
          </a>
          <button *ngIf="!sidebarCollapsed" 
                  (click)="toggleSidebar()"
                  class="p-1 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
            <lucide-icon [img]="SquareChevronLeftIcon" size="20"></lucide-icon>
          </button>
        </div>

        <!-- Collapse button when sidebar is collapsed -->
        <div *ngIf="sidebarCollapsed" class="flex justify-center mt-4">
          <button (click)="toggleSidebar()"
                  class="p-2 text-gray-400 hover:text-gray-600 dark:hover:text-gray-300 transition-colors">
            <lucide-icon [img]="SquareChevronRightIcon" size="20"></lucide-icon>
          </button>
        </div>

        <!-- Navigation -->
        <nav class="mt-5 px-2">
          <div class="space-y-1">
            <a routerLink="/dashboard" 
               [class.active]="isRouteActive('/dashboard')"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="HomeIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Dashboard</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Dashboard</div>
            </a>

            <a routerLink="/reports" 
               [class.active]="isRouteActive('/reports')"
               *ngIf="canAccessReports()"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="BarChart3Icon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Reports</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Reports</div>
            </a>
            
            <a routerLink="/reservations" 
               [class.active]="isRouteActive('/reservations')"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="CalendarIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Reservations</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Reservations</div>
            </a>

            <a routerLink="/cargo-management" 
               [class.active]="isRouteActive('/cargo-management')"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="PackageIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Cargo Management</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Cargo Management</div>
            </a>

            <a routerLink="/warehouse-operations" 
               [class.active]="isRouteActive('/warehouse-operations')"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="CogIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Warehouse Operations</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Warehouse Operations</div>
            </a>

            <a routerLink="/storage-requests" 
               [class.active]="isRouteActive('/storage-requests')"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="FileTextIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Storage Requests</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Storage Requests</div>
            </a>

            <a routerLink="/dock-management" 
               [class.active]="isRouteActive('/dock-management')"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="TruckIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Dock Management</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Dock Management</div>
            </a>

            <a routerLink="/warehouse-map" 
               [class.active]="isRouteActive('/warehouse-map')"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="MapPinIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Warehouse Map</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Warehouse Map</div>
            </a>

            <a routerLink="/customers" 
               [class.active]="isRouteActive('/customers')"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="UsersIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Customers</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Customers</div>
            </a>

            <a routerLink="/billing-payments" 
               [class.active]="isRouteActive('/billing-payments')"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="CreditCardIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Billing & Payments</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Billing & Payments</div>
            </a>

            <a routerLink="/employees" 
               [class.active]="isRouteActive('/employees')"
               *ngIf="canAccessEmployeeManagement()"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="UserCheckIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Employees</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Employees</div>
            </a>

            <a routerLink="/role-management" 
               [class.active]="isRouteActive('/role-management')"
               *ngIf="canAccessRoleManagement()"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="ShieldIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Role Management</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Role Management</div>
            </a>

            <a routerLink="/settings" 
               [class.active]="isRouteActive('/settings')"
               class="sidebar-nav-item group"
               [class.justify-center]="sidebarCollapsed">
              <lucide-icon [img]="SettingsIcon" size="20" class="flex-shrink-0"></lucide-icon>
              <span *ngIf="!sidebarCollapsed" class="ml-3">Settings</span>
              <div *ngIf="sidebarCollapsed" class="tooltip">Settings</div>
            </a>
          </div>
        </nav>
      </div>

      <!-- Main Content -->
      <div class="transition-all duration-300 ease-in-out"
           [class.pl-64]="!sidebarCollapsed"
           [class.pl-16]="sidebarCollapsed">
        <!-- Top Bar -->
        <div class="bg-white dark:bg-dark-800 shadow-sm border-b border-gray-200 dark:border-dark-700">
          <div class="px-4 sm:px-6 lg:px-8">
            <div class="flex justify-between h-16">
              <div class="flex items-center">
                <!-- Breadcrumb or page title could go here -->
              </div>
              
              <!-- User Menu -->
              <div class="flex items-center space-x-4">
                <!-- Notifications -->
                <div class="relative">
                  <button (click)="toggleNotifications()" 
                          class="p-2 text-gray-400 hover:text-gray-500 dark:hover:text-gray-300 relative">
                    <lucide-icon [img]="BellIcon" size="20"></lucide-icon>
                    <span *ngIf="unreadNotifications > 0" 
                          class="absolute -top-1 -right-1 h-5 w-5 bg-red-500 text-white text-xs rounded-full flex items-center justify-center">
                      {{ unreadNotifications }}
                    </span>
                  </button>
                  
                  <!-- Notifications Dropdown -->
                  <div *ngIf="showNotifications" 
                       class="absolute right-0 mt-2 w-80 bg-white dark:bg-dark-800 rounded-lg shadow-lg border border-gray-200 dark:border-dark-700 z-50">
                    <div class="p-4 border-b border-gray-200 dark:border-dark-700">
                      <div class="flex items-center justify-between">
                        <h3 class="text-lg font-medium text-gray-900 dark:text-white">Notifications</h3>
                        <button (click)="markAllAsRead()" 
                                class="text-sm text-primary-600 hover:text-primary-500">
                          Mark all read
                        </button>
                      </div>
                    </div>
                    <div class="max-h-96 overflow-y-auto">
                      <div *ngFor="let notification of notifications" 
                           class="p-4 border-b border-gray-100 dark:border-dark-700 hover:bg-gray-50 dark:hover:bg-dark-700 cursor-pointer"
                           [class.bg-blue-50]="!notification.isRead"
                           (click)="markAsRead(notification)">
                        <div class="flex items-start">
                          <div [class]="getNotificationIconClass(notification.type)" 
                               class="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center mr-3">
                            <lucide-icon [img]="getNotificationIcon(notification.type)" size="16"></lucide-icon>
                          </div>
                          <div class="flex-1 min-w-0">
                            <p class="text-sm font-medium text-gray-900 dark:text-white">{{ notification.title }}</p>
                            <p class="text-sm text-gray-600 dark:text-gray-400 mt-1">{{ notification.message }}</p>
                            <p class="text-xs text-gray-500 dark:text-gray-400 mt-2">{{ notification.createdAt | date:'MMM d, h:mm a' }}</p>
                          </div>
                          <div *ngIf="!notification.isRead" class="w-2 h-2 bg-blue-500 rounded-full flex-shrink-0"></div>
                        </div>
                      </div>
                      <div *ngIf="notifications.length === 0" class="p-8 text-center">
                        <lucide-icon [img]="BellIcon" size="48" class="mx-auto text-gray-400 mb-4"></lucide-icon>
                        <p class="text-gray-500 dark:text-gray-400">No notifications</p>
                      </div>
                    </div>
                  </div>
                </div>

                <!-- User Profile -->
                <div class="flex items-center space-x-3">
                  <div class="flex-shrink-0">
                    <div class="h-8 w-8 rounded-full bg-primary-600 flex items-center justify-center">
                      <span class="text-sm font-medium text-white">
                        {{ currentUser?.name?.charAt(0) || 'U' }}
                      </span>
                    </div>
                  </div>
                  <div class="hidden md:block">
                    <div class="text-sm font-medium text-gray-900 dark:text-white">{{ currentUser?.name || 'User' }}</div>
                    <div class="text-sm text-gray-500 dark:text-gray-400">{{ getUserRole() }}</div>
                  </div>
                  <button (click)="logout()" 
                          class="text-gray-400 hover:text-gray-500 dark:hover:text-gray-300">
                    <lucide-icon [img]="LogOutIcon" size="18"></lucide-icon>
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>

        <!-- Page Content -->
        <main class="p-6">
          <router-outlet></router-outlet>
        </main>
      </div>
    </div>

    <!-- Toast Notifications -->
    <div class="fixed bottom-4 right-4 z-50 space-y-2">
      <div *ngFor="let toast of toastNotifications" 
           class="transform transition-all duration-300 ease-in-out"
           [class]="getToastClass(toast.type)">
        <div class="flex items-center p-4 rounded-lg shadow-lg max-w-sm">
          <div [class]="getToastIconClass(toast.type)" 
               class="flex-shrink-0 w-8 h-8 rounded-full flex items-center justify-center mr-3">
            <lucide-icon [img]="getToastIcon(toast.type)" size="16" class="text-white"></lucide-icon>
          </div>
          <div class="flex-1">
            <p class="text-sm font-medium text-white">{{ toast.title }}</p>
            <p *ngIf="toast.message" class="text-sm text-white opacity-90 mt-1">{{ toast.message }}</p>
          </div>
          <button (click)="dismissToast(toast)" class="ml-3 text-white opacity-70 hover:opacity-100">
            <svg class="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path fill-rule="evenodd" d="M4.293 4.293a1 1 0 011.414 0L10 8.586l4.293-4.293a1 1 0 111.414 1.414L11.414 10l4.293 4.293a1 1 0 01-1.414 1.414L10 11.414l-4.293 4.293a1 1 0 01-1.414-1.414L8.586 10 4.293 5.707a1 1 0 010-1.414z" clip-rule="evenodd"></path>
            </svg>
          </button>
        </div>
      </div>
    </div>
  `,
  styles: [`
    .tooltip {
      @apply absolute left-full ml-2 px-2 py-1 bg-gray-900 text-white text-xs rounded opacity-0 pointer-events-none transition-opacity duration-200 whitespace-nowrap z-50;
    }
    
    .group:hover .tooltip {
      @apply opacity-100;
    }
    
    .sidebar-nav-item {
      @apply flex items-center px-3 py-2 text-sm font-medium rounded-md transition-colors hover:bg-gray-100 dark:hover:bg-dark-700 relative text-gray-700 dark:text-gray-300;
    }
    
    .sidebar-nav-item.active {
      @apply bg-primary-100 dark:bg-primary-900 text-primary-700 dark:text-primary-300;
    }
  `]
})
export class LayoutComponent implements OnInit {
  currentUser: UserProfile | null = null;
  sidebarCollapsed = false;
  currentRoute = '';
  showNotifications = false;
  notifications: any[] = [];
  unreadNotifications = 0;
  toastNotifications: any[] = [];

  // Lucide icons
  SquareChevronLeftIcon = SquareChevronLeft;
  SquareChevronRightIcon = SquareChevronRight;
  BellIcon = Bell;
  LogOutIcon = LogOut;
  BarChart3Icon = BarChart3;
  PackageIcon = Package;
  FileTextIcon = FileText;
  MapPinIcon = MapPin;
  TruckIcon = Truck;
  UsersIcon = Users;
  CreditCardIcon = CreditCard;
  HomeIcon = Home;
  CalendarIcon = Calendar;
  UserCheckIcon = UserCheck;
  SettingsIcon = Settings;
  ShieldIcon = Shield;
  CogIcon = Cog;

  constructor(
    private authService: AuthService,
    private router: Router,
    private notificationService: NotificationService
  ) {}

  ngOnInit(): void {
    this.authService.currentUser$.subscribe(user => {
      this.currentUser = user;
      if (user) {
        this.loadNotifications();
      }
    });

    // Track current route for active navigation highlighting
    this.router.events.pipe(
      filter(event => event instanceof NavigationEnd)
    ).subscribe((event: NavigationEnd) => {
      this.currentRoute = event.url;
    });

    // Subscribe to toast notifications
    this.notificationService.toastNotifications$.subscribe(toasts => {
      this.toastNotifications = toasts;
    });

    // Close notifications dropdown when clicking outside
    document.addEventListener('click', (event) => {
      if (!event.target || !(event.target as Element).closest('.relative')) {
        this.showNotifications = false;
      }
    });
  }

  loadNotifications(): void {
    // Mock notifications
    this.notifications = [
      {
        id: 1,
        title: 'New Storage Request',
        message: 'ABC Corp has submitted a new storage request',
        type: 'info',
        isRead: false,
        createdAt: new Date()
      },
      {
        id: 2,
        title: 'Dock Assignment Complete',
        message: 'Truck ABC-123 has been assigned to Dock 2',
        type: 'success',
        isRead: false,
        createdAt: new Date(Date.now() - 30 * 60 * 1000)
      },
      {
        id: 3,
        title: 'Low Stock Alert',
        message: 'Electronics inventory is running low',
        type: 'warning',
        isRead: true,
        createdAt: new Date(Date.now() - 2 * 60 * 60 * 1000)
      }
    ];
    this.unreadNotifications = this.notifications.filter(n => !n.isRead).length;
  }

  toggleSidebar(): void {
    this.sidebarCollapsed = !this.sidebarCollapsed;
  }

  toggleNotifications(): void {
    this.showNotifications = !this.showNotifications;
  }

  markAsRead(notification: any): void {
    notification.isRead = true;
    this.unreadNotifications = this.notifications.filter(n => !n.isRead).length;
  }

  markAllAsRead(): void {
    this.notifications.forEach(n => n.isRead = true);
    this.unreadNotifications = 0;
  }

  dismissToast(toast: any): void {
    this.notificationService.dismissToast(toast.id);
  }

  getNotificationIcon(type: string) {
    switch (type) {
      case 'success': return this.PackageIcon;
      case 'warning': return this.BellIcon;
      case 'error': return this.BellIcon;
      default: return this.BellIcon;
    }
  }

  getNotificationIconClass(type: string): string {
    switch (type) {
      case 'success': return 'bg-success-100 text-success-600';
      case 'warning': return 'bg-warning-100 text-warning-600';
      case 'error': return 'bg-error-100 text-error-600';
      default: return 'bg-primary-100 text-primary-600';
    }
  }

  getToastIcon(type: string) {
    return this.getNotificationIcon(type);
  }

  getToastIconClass(type: string): string {
    switch (type) {
      case 'success': return 'bg-success-600';
      case 'warning': return 'bg-warning-600';
      case 'error': return 'bg-error-600';
      default: return 'bg-primary-600';
    }
  }

  getToastClass(type: string): string {
    switch (type) {
      case 'success': return 'bg-success-600';
      case 'warning': return 'bg-warning-600';
      case 'error': return 'bg-error-600';
      default: return 'bg-primary-600';
    }
  }

  isRouteActive(route: string): boolean {
    return this.currentRoute.startsWith(route);
  }

  getUserRole(): string {
    return this.currentUser?.role?.[0]?.roleName || 'N/A';
  }

  canAccessReports(): boolean {
    return this.authService.hasRole('Warehouse Manager');
  }

  canAccessEmployeeManagement(): boolean {
    return this.authService.hasRole('Warehouse Manager');
  }

  canAccessRoleManagement(): boolean {
    return this.authService.hasRole('Warehouse Manager');
  }

  logout(): void {
    this.authService.logout();
    this.router.navigate(['/login']);
  }
}