import { Injectable, signal, computed } from '@angular/core';

export interface CustomersListingFilters {
  searchTerm: string;
  status: string;
}

@Injectable({
  providedIn: 'root'
})
export class CustomersListingFiltersService {
  // Signals for filter state
  private _searchTerm = signal<string>('');
  private _status = signal<string>('');

  // Computed signal that combines all filters
  filters = computed<CustomersListingFilters>(() => ({
    searchTerm: this._searchTerm(),
    status: this._status()
  }));

  // Individual filter getters
  get searchTerm() { return this._searchTerm.asReadonly(); }
  get status() { return this._status.asReadonly(); }

  // Filter setters
  setSearchTerm(searchTerm: string): void {
    this._searchTerm.set(searchTerm);
  }

  setStatus(status: string): void {
    this._status.set(status);
  }

  // Reset all filters
  resetFilters(): void {
    this._searchTerm.set('');
    this._status.set('');
  }

  // Check if any filters are active
  hasActiveFilters = computed<boolean>(() => {
    const filters = this.filters();
    return !!(filters.searchTerm || filters.status);
  });
}