import { Component, OnInit, effect } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterLink } from '@angular/router';
import { FormsModule, ReactiveFormsModule, FormBuilder, FormGroup, Validators } from '@angular/forms';
import { CustomersService } from './customers.service';
import { CustomersListingFiltersService } from './customers-listing-filters.service';
import { NotificationService } from '../notifications/notification.service';
import { Customer } from './customers.interfaces';
import { CustomersStatsComponent } from './customers-stats.component';
import { CustomersListingFiltersComponent } from './customers-listing-filters.component';
import { CustomersListingComponent } from './customers-listing.component';
import { LucideAngularModule, Plus, X, UserMinus } from 'lucide-angular';

@Component({
  selector: 'app-customers',
  standalone: true,
  imports: [
    CommonModule, 
    RouterLink, 
    FormsModule,
    ReactiveFormsModule,
    LucideAngularModule,
    CustomersStatsComponent,
    CustomersListingFiltersComponent,
    CustomersListingComponent
  ],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div class="flex justify-between items-center">
        <div>
          <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Customers</h1>
          <p class="text-gray-600 dark:text-gray-400">Manage customer information and contacts</p>
        </div>
        <button (click)="showAddCustomerModal = true" class="btn btn-primary">
          <lucide-icon [img]="PlusIcon" size="18" class="mr-2"></lucide-icon>
          Add Customer
        </button>
      </div>

      <!-- Stats Component -->
      <app-customers-stats [customers]="customers" />

      <!-- Filters Component -->
      <app-customers-listing-filters />

      <!-- Listing Component -->
      <app-customers-listing 
        [customers]="filteredCustomers" 
        (deactivateCustomer)="deactivateCustomer($event)" />
    </div>

    <!-- Add Customer Modal -->
    <div *ngIf="showAddCustomerModal" 
         class="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
      <div class="bg-white dark:bg-dark-800 rounded-lg shadow-xl max-w-2xl w-full mx-4 max-h-screen overflow-y-auto">
        <div class="flex items-center justify-between p-6 border-b border-gray-200 dark:border-dark-700">
          <h3 class="text-lg font-medium text-gray-900 dark:text-white">Add New Customer</h3>
          <button (click)="closeModal()" class="text-gray-400 hover:text-gray-600 dark:hover:text-gray-300">
            <lucide-icon [img]="XIcon" size="24"></lucide-icon>
          </button>
        </div>

        <form [formGroup]="customerForm" (ngSubmit)="onSubmit()" class="p-6">
          <div class="space-y-6">
            <!-- Company Information -->
            <div>
              <h4 class="text-md font-medium text-gray-900 dark:text-white mb-4">Company Information</h4>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label for="companyName" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Company Name *
                  </label>
                  <input type="text" 
                         id="companyName"
                         formControlName="companyName"
                         class="input"
                         placeholder="Enter company name">
                  <div *ngIf="customerForm.get('companyName')?.invalid && customerForm.get('companyName')?.touched" 
                       class="mt-1 text-sm text-error-600">
                    Company name is required
                  </div>
                </div>
                <div>
                  <label for="countryOfOrigin" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Country of Origin *
                  </label>
                  <select id="countryOfOrigin" formControlName="countryOfOrigin" class="input">
                    <option value="">Select country</option>
                    <option value="USA">United States</option>
                    <option value="Canada">Canada</option>
                    <option value="Mexico">Mexico</option>
                    <option value="UK">United Kingdom</option>
                    <option value="Germany">Germany</option>
                    <option value="France">France</option>
                  </select>
                  <div *ngIf="customerForm.get('countryOfOrigin')?.invalid && customerForm.get('countryOfOrigin')?.touched" 
                       class="mt-1 text-sm text-error-600">
                    Country is required
                  </div>
                </div>
              </div>
            </div>

            <!-- Contact Information -->
            <div>
              <h4 class="text-md font-medium text-gray-900 dark:text-white mb-4">Contact Information</h4>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label for="contactPerson" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Contact Person *
                  </label>
                  <input type="text" 
                         id="contactPerson"
                         formControlName="contactPerson"
                         class="input"
                         placeholder="Enter contact person name">
                  <div *ngIf="customerForm.get('contactPerson')?.invalid && customerForm.get('contactPerson')?.touched" 
                       class="mt-1 text-sm text-error-600">
                    Contact person is required
                  </div>
                </div>
                <div>
                  <label for="contactTitle" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Contact Title
                  </label>
                  <input type="text" 
                         id="contactTitle"
                         formControlName="contactTitle"
                         class="input"
                         placeholder="e.g., Operations Manager">
                </div>
                <div>
                  <label for="phone" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Phone Number *
                  </label>
                  <input type="tel" 
                         id="phone"
                         formControlName="phone"
                         class="input"
                         placeholder="+1-555-0123">
                  <div *ngIf="customerForm.get('phone')?.invalid && customerForm.get('phone')?.touched" 
                       class="mt-1 text-sm text-error-600">
                    Phone number is required
                  </div>
                </div>
                <div>
                  <label for="email" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Email Address *
                  </label>
                  <input type="email" 
                         id="email"
                         formControlName="email"
                         class="input"
                         placeholder="contact@company.com">
                  <div *ngIf="customerForm.get('email')?.invalid && customerForm.get('email')?.touched" 
                       class="mt-1 text-sm text-error-600">
                    Valid email is required
                  </div>
                </div>
              </div>
            </div>

            <!-- Address Information -->
            <div>
              <h4 class="text-md font-medium text-gray-900 dark:text-white mb-4">Address Information</h4>
              <div class="space-y-4">
                <div>
                  <label for="street" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Street Address *
                  </label>
                  <input type="text" 
                         id="street"
                         formControlName="street"
                         class="input"
                         placeholder="123 Business Street">
                  <div *ngIf="customerForm.get('street')?.invalid && customerForm.get('street')?.touched" 
                       class="mt-1 text-sm text-error-600">
                    Street address is required
                  </div>
                </div>
                <div class="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label for="city" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      City *
                    </label>
                    <input type="text" 
                           id="city"
                           formControlName="city"
                           class="input"
                           placeholder="City">
                    <div *ngIf="customerForm.get('city')?.invalid && customerForm.get('city')?.touched" 
                         class="mt-1 text-sm text-error-600">
                      City is required
                    </div>
                  </div>
                  <div>
                    <label for="state" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      State/Province *
                    </label>
                    <input type="text" 
                           id="state"
                           formControlName="state"
                           class="input"
                           placeholder="State">
                    <div *ngIf="customerForm.get('state')?.invalid && customerForm.get('state')?.touched" 
                         class="mt-1 text-sm text-error-600">
                      State is required
                    </div>
                  </div>
                  <div>
                    <label for="postalCode" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                      Postal Code *
                    </label>
                    <input type="text" 
                           id="postalCode"
                           formControlName="postalCode"
                           class="input"
                           placeholder="12345">
                    <div *ngIf="customerForm.get('postalCode')?.invalid && customerForm.get('postalCode')?.touched" 
                         class="mt-1 text-sm text-error-600">
                      Postal code is required
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Tax Information -->
            <div>
              <h4 class="text-md font-medium text-gray-900 dark:text-white mb-4">Tax Information</h4>
              <div class="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div>
                  <label for="taxId" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tax ID
                  </label>
                  <input type="text" 
                         id="taxId"
                         formControlName="taxId"
                         class="input"
                         placeholder="TAX-123-456">
                </div>
                <div>
                  <label for="taxNumber" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tax Number
                  </label>
                  <input type="text" 
                         id="taxNumber"
                         formControlName="taxNumber"
                         class="input"
                         placeholder="12-3456789">
                </div>
                <div>
                  <label for="vatNumber" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    VAT Number
                  </label>
                  <input type="text" 
                         id="vatNumber"
                         formControlName="vatNumber"
                         class="input"
                         placeholder="US123456789">
                </div>
                <div>
                  <label for="taxRate" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                    Tax Rate (%)
                  </label>
                  <input type="number" 
                         id="taxRate"
                         formControlName="taxRate"
                         class="input"
                         placeholder="8.5"
                         min="0"
                         max="100"
                         step="0.1">
                </div>
              </div>
              <div class="mt-4">
                <label class="flex items-center">
                  <input type="checkbox" 
                         formControlName="taxExempt"
                         class="h-4 w-4 text-primary-600 focus:ring-primary-500 border-gray-300 rounded">
                  <span class="ml-2 text-sm text-gray-700 dark:text-gray-300">Tax Exempt</span>
                </label>
              </div>
            </div>

            <!-- Notes -->
            <div>
              <label for="notes" class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">
                Notes
              </label>
              <textarea id="notes" 
                        formControlName="notes"
                        rows="3"
                        class="input"
                        placeholder="Additional notes about the customer..."></textarea>
            </div>
          </div>

          <!-- Modal Actions -->
          <div class="flex justify-end space-x-3 mt-6 pt-6 border-t border-gray-200 dark:border-dark-700">
            <button type="button" 
                    (click)="closeModal()"
                    class="btn btn-secondary">
              Cancel
            </button>
            <button type="submit" 
                    [disabled]="customerForm.invalid || submitting"
                    class="btn btn-primary">
              {{ submitting ? 'Creating...' : 'Create Customer' }}
            </button>
          </div>
        </form>
      </div>
    </div>
  `
})
export class CustomersComponent implements OnInit {
  customers: Customer[] = [];
  filteredCustomers: Customer[] = [];
  showAddCustomerModal = false;
  submitting = false;
  customerForm: FormGroup;

  // Lucide icons
  PlusIcon = Plus;
  XIcon = X;
  UserMinusIcon = UserMinus;

  constructor(
    private customersService: CustomersService,
    private filtersService: CustomersListingFiltersService,
    private notificationService: NotificationService,
    private formBuilder: FormBuilder
  ) {
    // Effect to automatically filter customers when filters change
    effect(() => {
      this.applyFilters();
    });

    this.customerForm = this.formBuilder.group({
      companyName: ['', Validators.required],
      contactPerson: ['', Validators.required],
      contactTitle: [''],
      phone: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      street: ['', Validators.required],
      city: ['', Validators.required],
      state: ['', Validators.required],
      postalCode: ['', Validators.required],
      countryOfOrigin: ['', Validators.required],
      taxId: [''],
      taxNumber: [''],
      vatNumber: [''],
      taxRate: [0],
      taxExempt: [false],
      notes: ['']
    });
  }

  ngOnInit(): void {
    this.loadCustomers();
  }

  loadCustomers(): void {
    this.customersService.getCustomers().subscribe(customers => {
      this.customers = customers;
      this.filteredCustomers = customers;
    });
  }

  applyFilters(): void {
    const filters = this.filtersService.filters();
    
    this.filteredCustomers = this.customers.filter(customer => {
      // Search term filter
      if (filters.searchTerm) {
        const searchLower = filters.searchTerm.toLowerCase();
        if (!customer.companyName.toLowerCase().includes(searchLower) &&
            !customer.contactPerson.toLowerCase().includes(searchLower) &&
            !customer.phone.toLowerCase().includes(searchLower)) {
          return false;
        }
      }

      // Status filter
      if (filters.status && customer.status !== filters.status) {
        return false;
      }

      return true;
    });
  }

  deactivateCustomer(customer: Customer): void {
    // Simulate deactivation
    customer.status = 'inactive';
    
    // Show toast notification
    this.notificationService.showWarning(
      'Customer Deactivated',
      `${customer.companyName} has been deactivated successfully.`
    );
  }

  closeModal(): void {
    this.showAddCustomerModal = false;
    this.customerForm.reset();
  }

  onSubmit(): void {
    if (this.customerForm.invalid) {
      return;
    }

    this.submitting = true;
    const formData = this.customerForm.value;

    // Simulate API call
    setTimeout(() => {
      const newCustomer: Customer = {
        id: Math.max(...this.customers.map(c => c.id)) + 1,
        companyName: formData.companyName,
        contactPerson: formData.contactPerson,
        contactTitle: formData.contactTitle,
        phone: formData.phone,
        email: formData.email,
        address: {
          street: formData.street,
          city: formData.city,
          state: formData.state,
          postalCode: formData.postalCode,
          country: formData.countryOfOrigin
        },
        taxId: formData.taxId,
        taxInfo: {
          taxNumber: formData.taxNumber,
          vatNumber: formData.vatNumber,
          taxExempt: formData.taxExempt,
          taxRate: formData.taxRate
        },
        countryOfOrigin: formData.countryOfOrigin,
        status: 'active',
        createdAt: new Date(),
        updatedAt: new Date(),
        notes: formData.notes
      };

      this.customers.push(newCustomer);
      this.applyFilters();
      
      this.notificationService.showSuccess(
        'Customer Created',
        `${newCustomer.companyName} has been added successfully.`
      );

      this.closeModal();
      this.submitting = false;
    }, 1000);
  }
}