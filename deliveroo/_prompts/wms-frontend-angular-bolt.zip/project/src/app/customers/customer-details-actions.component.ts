import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Customer } from './customers.interfaces';
import { LucideAngularModule, Edit, CreditCard } from 'lucide-angular';

@Component({
  selector: 'app-customer-details-actions',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <div class="flex space-x-3" *ngIf="customer()">
      <button class="btn btn-secondary">
        <lucide-icon [img]="EditIcon" size="18" class="mr-2"></lucide-icon>
        Edit Customer
      </button>
      <button class="btn btn-primary">
        <lucide-icon [img]="CreditCardIcon" size="18" class="mr-2"></lucide-icon>
        Create Invoice
      </button>
    </div>
  `
})
export class CustomerDetailsActionsComponent {
  // Signal-based input
  customer = input<Customer | null>(null);

  // Lucide icons
  EditIcon = Edit;
  CreditCardIcon = CreditCard;
}