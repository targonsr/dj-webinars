// User Authentication
export interface LoginCredentials {
  username: string;
  password: string;
  rememberMe?: boolean;
}

export interface AuthResponse {
  token: string;
  refreshToken: string;
  user: UserProfile;
  expiresAt: number;
}

// User Profile
export interface UserProfile {
  id: number;
  name: string;
  email: string;
  phone?: string;
  role: UserRole[];
  warehouseAssignments: WarehouseAssignment[];
  lastLogin: Date;
  isActive: boolean;
}

export interface UserRole {
  roleId: number;
  roleName: string;
  description: string;
  permissions: Permission[];
  assignedDate: Date;
}

export interface Permission {
  id: number;
  name: string;
  description: string;
  resource: string;
  action: 'create' | 'read' | 'update' | 'delete';
}

export interface WarehouseAssignment {
  warehouseId: number;
  warehouseName: string;
  assignedFrom: Date;
  assignedUntil?: Date;
  isActive: boolean;
}

// Warehouse Structure
export interface Warehouse {
  id: number;
  name: string;
  description?: string;
  location: Location;
  zones: Zone[];
  capacity: Capacity;
  isActive: boolean;
}

export interface Location {
  id: number;
  address: string;
  city: string;
  postalCode: string;
  country: string;
  coordinates?: {
    latitude: number;
    longitude: number;
  };
}

export interface Zone {
  id: number;
  warehouseId: number;
  name: string;
  description?: string;
  zoneType: 'standard' | 'refrigerated' | 'frozen' | 'hazardous' | 'secure';
  temperature?: {
    min: number;
    max: number;
    unit: 'C' | 'F';
  };
  aisles: Aisle[];
  capacity: Capacity;
}

export interface Aisle {
  id: number;
  zoneId: number;
  label: string;
  width: number;
  widthUnit: string;
  racks: Rack[];
}

export interface Rack {
  id: number;
  aisleId: number;
  label: string;
  maxHeight: number;
  heightUnit: string;
  shelves: Shelf[];
}

export interface Shelf {
  id: number;
  rackId: number;
  level: string;
  maxWeight: number;
  maxVolume: number;
  currentWeight?: number;
  currentVolume?: number;
  isAvailable: boolean;
  storageRecords: StorageRecord[];
}

export interface Capacity {
  id: number;
  entityType: 'WAREHOUSE' | 'ZONE' | 'RACK' | 'SHELF';
  entityId: number;
  value: number;
  unit: string;
  description?: string;
  usedCapacity?: number;
  availableCapacity?: number;
  utilizationPercentage?: number;
}

// Storage Request
export interface StorageRequest {
  id: number;
  customerId: number;
  customerName: string;
  warehouseId: number;
  requestedEntryDate: Date;
  requestedExitDate: Date;
  status: 'pending' | 'accepted' | 'rejected';
  decisionEmployeeId?: number;
  decisionEmployeeName?: string;
  decisionDate?: Date;
  cargoDetails: CargoDetails;
  reservations: StorageReservation[];
  createdAt: Date;
  updatedAt: Date;
}

export interface CargoDetails {
  description: string;
  weight: number;
  volume: number;
  requiresRefrigeration: boolean;
  requiresFreezing: boolean;
  isHazardous: boolean;
  hazardousClassification?: string;
  specialHandlingInstructions?: string;
  containsPerishables: boolean;
  estimatedValue?: number;
  currency?: string;
}

// Storage Reservation
export interface StorageReservation {
  id: number;
  requestId: number;
  customerId: number;
  shelfId: number;
  shelfLocation: string;
  reservedWeight: number;
  reservedVolume: number;
  reservedFrom: Date;
  reservedUntil: Date;
  status: 'pending' | 'active' | 'expired' | 'cancelled';
  createdAt: Date;
  updatedAt: Date;
}

// Storage Record
export interface StorageRecord {
  id: number;
  requestId: number;
  customerId: number;
  shelfId: number;
  shelfLocation: string;
  actualEntryDate: Date;
  actualExitDate?: Date;
  cargoDescription: string;
  cargoWeight: number;
  cargoVolume: number;
  events: CargoEventHistory[];
  payments: Payment[];
  createdAt: Date;
  updatedAt: Date;
}

// Cargo Event History
export interface CargoEventHistory {
  id: number;
  storageRecordId: number;
  eventTypeId: number;
  eventTypeName: string;
  eventTime: Date;
  employeeId: number;
  employeeName: string;
  details: any;
}

// Payment
export interface Payment {
  id: number;
  storageRecordId: number;
  customerId: number;
  amount: number;
  currency: string;
  status: 'pending' | 'paid' | 'failed' | 'cancelled';
  paymentDate?: Date;
  externalReference?: string;
  createdAt: Date;
  updatedAt: Date;
}

// Dock Management
export interface Dock {
  id: number;
  warehouseId: number;
  name: string;
  type: 'receiving' | 'shipping' | 'both';
  status: 'available' | 'occupied' | 'maintenance' | 'reserved';
  currentTruck?: Truck;
  appointments: DockAppointment[];
}

export interface DockAppointment {
  id: number;
  dockId: number;
  truckId: number;
  carrierId: number;
  carrierName: string;
  appointmentType: 'receiving' | 'shipping';
  scheduledStart: Date;
  scheduledEnd: Date;
  actualStart?: Date;
  actualEnd?: Date;
  status: 'scheduled' | 'in_progress' | 'completed' | 'cancelled' | 'no_show';
  relatedStorageRequestIds: number[];
  cargoDescription?: string;
}

export interface Truck {
  id: number;
  licensePlate: string;
  carrierId: number;
  carrierName: string;
  driverId: number;
  driverName: string;
  driverPhone: string;
  truckType: string;
  capacity: number;
  capacityUnit: string;
}

// Inventory Management
export interface InventoryItem {
  id: number;
  sku: string;
  name: string;
  description: string;
  category: string;
  quantity: number;
  unit: string;
  location: string;
  zoneId: number;
  zoneName: string;
  shelfId: number;
  shelfLocation: string;
  weight: number;
  volume: number;
  value: number;
  currency: string;
  status: 'available' | 'reserved' | 'damaged' | 'expired';
  expiryDate?: Date;
  batchNumber?: string;
  serialNumber?: string;
  lastUpdated: Date;
  customerId?: number;
  customerName?: string;
}

export interface InventoryAdjustment {
  id: number;
  itemId: number;
  itemSku: string;
  itemName: string;
  adjustmentType: 'increase' | 'decrease' | 'correction';
  quantityBefore: number;
  quantityAfter: number;
  quantityChanged: number;
  reason: string;
  employeeId: number;
  employeeName: string;
  createdAt: Date;
  notes?: string;
}

export interface StockTransfer {
  id: number;
  itemId: number;
  itemSku: string;
  itemName: string;
  fromLocationId: number;
  fromLocation: string;
  toLocationId: number;
  toLocation: string;
  quantity: number;
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  requestedBy: number;
  requestedByName: string;
  approvedBy?: number;
  approvedByName?: string;
  transferredBy?: number;
  transferredByName?: string;
  requestedAt: Date;
  approvedAt?: Date;
  completedAt?: Date;
  notes?: string;
}

export interface InventoryOverview {
  totalItems: number;
  totalValue: number;
  lowStockItems: number;
  expiringSoonItems: number;
  damagedItems: number;
  categoryBreakdown: {
    category: string;
    count: number;
    value: number;
  }[];
  zoneUtilization: {
    zoneId: number;
    zoneName: string;
    utilization: number;
    itemCount: number;
  }[];
}

// Dashboard
export interface DashboardStats {
  totalCapacity: number;
  usedCapacity: number;
  pendingRequests: number;
  activeReservations: number;
  todayArrivals: number;
  todayDepartures: number;
  revenue: number;
  utilizationRate: number;
}

export interface Task {
  id: number;
  title: string;
  description: string;
  assignedTo: number;
  assignedBy: number;
  dueDate: Date;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  type: 'storage' | 'retrieval' | 'maintenance' | 'inspection';
  relatedEntityId?: number;
  createdAt: Date;
  updatedAt: Date;
}

export interface Notification {
  id: number;
  userId: number;
  title: string;
  message: string;
  type: 'info' | 'success' | 'warning' | 'error';
  isRead: boolean;
  actionUrl?: string;
  createdAt: Date;
}