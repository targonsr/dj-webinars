import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { LucideAngularModule, Users, User, Clock, CheckCircle, AlertCircle, Plus, Eye, Edit } from 'lucide-angular';

interface Task {
  id: number;
  title: string;
  description: string;
  assignedTo: string;
  assignedToId: number;
  priority: 'low' | 'medium' | 'high' | 'urgent';
  status: 'pending' | 'in_progress' | 'completed' | 'cancelled';
  dueDate: Date;
  estimatedHours: number;
  category: 'receiving' | 'shipping' | 'inventory' | 'maintenance' | 'quality';
  location: string;
}

@Component({
  selector: 'app-warehouse-operations-task-assignment',
  standalone: true,
  imports: [CommonModule, FormsModule, LucideAngularModule],
  template: `
    <div class="p-6">
      <div class="flex justify-between items-center mb-6">
        <h3 class="text-lg font-medium text-gray-900 dark:text-white">Task Assignment</h3>
        <button class="btn btn-primary">
          <lucide-icon [img]="PlusIcon" size="18" class="mr-2"></lucide-icon>
          Create Task
        </button>
      </div>

      <!-- Task Overview -->
      <div class="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
        <div class="card p-6">
          <div class="flex items-center">
            <div class="p-2 bg-primary-100 rounded-lg">
              <lucide-icon [img]="ClockIcon" size="24" class="text-primary-600"></lucide-icon>
            </div>
            <div class="ml-4">
              <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Pending Tasks</p>
              <p class="text-2xl font-semibold text-gray-900 dark:text-white">{{ getPendingTasks() }}</p>
            </div>
          </div>
        </div>

        <div class="card p-6">
          <div class="flex items-center">
            <div class="p-2 bg-warning-100 rounded-lg">
              <lucide-icon [img]="AlertCircleIcon" size="24" class="text-warning-600"></lucide-icon>
            </div>
            <div class="ml-4">
              <p class="text-sm font-medium text-gray-600 dark:text-gray-400">In Progress</p>
              <p class="text-2xl font-semibold text-gray-900 dark:text-white">{{ getInProgressTasks() }}</p>
            </div>
          </div>
        </div>

        <div class="card p-6">
          <div class="flex items-center">
            <div class="p-2 bg-success-100 rounded-lg">
              <lucide-icon [img]="CheckCircleIcon" size="24" class="text-success-600"></lucide-icon>
            </div>
            <div class="ml-4">
              <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Completed Today</p>
              <p class="text-2xl font-semibold text-gray-900 dark:text-white">{{ getCompletedToday() }}</p>
            </div>
          </div>
        </div>

        <div class="card p-6">
          <div class="flex items-center">
            <div class="p-2 bg-secondary-100 rounded-lg">
              <lucide-icon [img]="UsersIcon" size="24" class="text-secondary-600"></lucide-icon>
            </div>
            <div class="ml-4">
              <p class="text-sm font-medium text-gray-600 dark:text-gray-400">Active Workers</p>
              <p class="text-2xl font-semibold text-gray-900 dark:text-white">{{ getActiveWorkers() }}</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Task Filters -->
      <div class="card p-4 mb-6">
        <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Status</label>
            <select [(ngModel)]="statusFilter" (change)="applyFilters()" class="input">
              <option value="">All Status</option>
              <option value="pending">Pending</option>
              <option value="in_progress">In Progress</option>
              <option value="completed">Completed</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Priority</label>
            <select [(ngModel)]="priorityFilter" (change)="applyFilters()" class="input">
              <option value="">All Priorities</option>
              <option value="urgent">Urgent</option>
              <option value="high">High</option>
              <option value="medium">Medium</option>
              <option value="low">Low</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Category</label>
            <select [(ngModel)]="categoryFilter" (change)="applyFilters()" class="input">
              <option value="">All Categories</option>
              <option value="receiving">Receiving</option>
              <option value="shipping">Shipping</option>
              <option value="inventory">Inventory</option>
              <option value="maintenance">Maintenance</option>
              <option value="quality">Quality</option>
            </select>
          </div>
          <div>
            <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-1">Assigned To</label>
            <select [(ngModel)]="assigneeFilter" (change)="applyFilters()" class="input">
              <option value="">All Workers</option>
              <option value="Mike Worker">Mike Worker</option>
              <option value="Sarah Coordinator">Sarah Coordinator</option>
              <option value="John Operator">John Operator</option>
            </select>
          </div>
        </div>
      </div>

      <!-- Tasks Table -->
      <div class="card overflow-hidden">
        <div class="overflow-x-auto">
          <table class="min-w-full divide-y divide-gray-200 dark:divide-dark-700">
            <thead class="bg-gray-50 dark:bg-dark-800">
              <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Task
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Assigned To
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Priority
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Due Date
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Status
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Location
                </th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                  Actions
                </th>
              </tr>
            </thead>
            <tbody class="bg-white dark:bg-dark-800 divide-y divide-gray-200 dark:divide-dark-700">
              <tr *ngFor="let task of filteredTasks" class="hover:bg-gray-50 dark:hover:bg-dark-700">
                <td class="px-6 py-4">
                  <div class="text-sm font-medium text-gray-900 dark:text-white">{{ task.title }}</div>
                  <div class="text-sm text-gray-500 dark:text-gray-400">{{ task.description }}</div>
                  <div class="mt-1">
                    <span [class]="getCategoryClass(task.category)" 
                          class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium">
                      {{ task.category | titlecase }}
                    </span>
                  </div>
                </td>
                <td class="px-6 py-4">
                  <div class="flex items-center">
                    <div class="flex-shrink-0 h-8 w-8">
                      <div class="h-8 w-8 rounded-full bg-primary-100 flex items-center justify-center">
                        <lucide-icon [img]="UserIcon" size="16" class="text-primary-600"></lucide-icon>
                      </div>
                    </div>
                    <div class="ml-3">
                      <div class="text-sm font-medium text-gray-900 dark:text-white">{{ task.assignedTo }}</div>
                      <div class="text-sm text-gray-500 dark:text-gray-400">{{ task.estimatedHours }}h estimated</div>
                    </div>
                  </div>
                </td>
                <td class="px-6 py-4">
                  <span [class]="getPriorityClass(task.priority)" 
                        class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium">
                    {{ task.priority | titlecase }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                  {{ task.dueDate | date:'MMM d, y h:mm a' }}
                </td>
                <td class="px-6 py-4">
                  <span [class]="getStatusClass(task.status)" 
                        class="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium">
                    {{ task.status | titlecase }}
                  </span>
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500 dark:text-gray-400">
                  {{ task.location }}
                </td>
                <td class="px-6 py-4 text-sm font-medium space-x-2">
                  <button class="text-primary-600 hover:text-primary-500 inline-flex items-center">
                    <lucide-icon [img]="EyeIcon" size="16" class="mr-1"></lucide-icon>
                    View
                  </button>
                  <button class="text-secondary-600 hover:text-secondary-500 inline-flex items-center">
                    <lucide-icon [img]="EditIcon" size="16" class="mr-1"></lucide-icon>
                    Edit
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  `
})
export class WarehouseOperationsTaskAssignmentComponent implements OnInit {
  statusFilter = '';
  priorityFilter = '';
  categoryFilter = '';
  assigneeFilter = '';
  filteredTasks: Task[] = [];

  tasks: Task[] = [
    {
      id: 1,
      title: 'Receive Electronics Shipment',
      description: 'Process incoming electronics from ABC Corp',
      assignedTo: 'Mike Worker',
      assignedToId: 3,
      priority: 'high',
      status: 'pending',
      dueDate: new Date('2025-01-15T10:00:00'),
      estimatedHours: 3,
      category: 'receiving',
      location: 'Dock 1'
    },
    {
      id: 2,
      title: 'Inventory Count - Zone A',
      description: 'Perform cycle count for Zone A electronics',
      assignedTo: 'Sarah Coordinator',
      assignedToId: 2,
      priority: 'medium',
      status: 'in_progress',
      dueDate: new Date('2025-01-15T16:00:00'),
      estimatedHours: 4,
      category: 'inventory',
      location: 'Zone A'
    },
    {
      id: 3,
      title: 'Forklift Maintenance',
      description: 'Scheduled maintenance for Forklift #3',
      assignedTo: 'John Operator',
      assignedToId: 4,
      priority: 'urgent',
      status: 'pending',
      dueDate: new Date('2025-01-15T08:00:00'),
      estimatedHours: 2,
      category: 'maintenance',
      location: 'Maintenance Bay'
    }
  ];

  // Lucide icons
  UsersIcon = Users;
  UserIcon = User;
  ClockIcon = Clock;
  CheckCircleIcon = CheckCircle;
  AlertCircleIcon = AlertCircle;
  PlusIcon = Plus;
  EyeIcon = Eye;
  EditIcon = Edit;

  ngOnInit(): void {
    this.filteredTasks = [...this.tasks];
  }

  applyFilters(): void {
    this.filteredTasks = this.tasks.filter(task => {
      if (this.statusFilter && task.status !== this.statusFilter) return false;
      if (this.priorityFilter && task.priority !== this.priorityFilter) return false;
      if (this.categoryFilter && task.category !== this.categoryFilter) return false;
      if (this.assigneeFilter && task.assignedTo !== this.assigneeFilter) return false;
      return true;
    });
  }

  getPendingTasks(): number {
    return this.tasks.filter(t => t.status === 'pending').length;
  }

  getInProgressTasks(): number {
    return this.tasks.filter(t => t.status === 'in_progress').length;
  }

  getCompletedToday(): number {
    return this.tasks.filter(t => t.status === 'completed').length;
  }

  getActiveWorkers(): number {
    const activeWorkers = new Set(this.tasks.filter(t => t.status === 'in_progress').map(t => t.assignedToId));
    return activeWorkers.size;
  }

  getPriorityClass(priority: string): string {
    switch (priority) {
      case 'urgent': return 'bg-error-100 text-error-800';
      case 'high': return 'bg-warning-100 text-warning-800';
      case 'medium': return 'bg-primary-100 text-primary-800';
      case 'low': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  getStatusClass(status: string): string {
    switch (status) {
      case 'completed': return 'bg-success-100 text-success-800';
      case 'in_progress': return 'bg-primary-100 text-primary-800';
      case 'pending': return 'bg-warning-100 text-warning-800';
      case 'cancelled': return 'bg-error-100 text-error-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }

  getCategoryClass(category: string): string {
    switch (category) {
      case 'receiving': return 'bg-blue-100 text-blue-800';
      case 'shipping': return 'bg-green-100 text-green-800';
      case 'inventory': return 'bg-purple-100 text-purple-800';
      case 'maintenance': return 'bg-orange-100 text-orange-800';
      case 'quality': return 'bg-pink-100 text-pink-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  }
}