import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { WarehouseOperationsZoneManagementComponent } from './warehouse-operations-zone-management.component';
import { WarehouseOperationsDockSchedulingComponent } from './warehouse-operations-dock-scheduling.component';
import { WarehouseOperationsTaskAssignmentComponent } from './warehouse-operations-task-assignment.component';
import { LucideAngularModule, Cog, MapPin, Calendar, Users } from 'lucide-angular';

@Component({
  selector: 'app-warehouse-operations',
  standalone: true,
  imports: [
    CommonModule,
    LucideAngularModule,
    WarehouseOperationsZoneManagementComponent,
    WarehouseOperationsDockSchedulingComponent,
    WarehouseOperationsTaskAssignmentComponent
  ],
  template: `
    <div class="space-y-6">
      <!-- Header -->
      <div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">Warehouse Operations</h1>
        <p class="text-gray-600 dark:text-gray-400">Configure and monitor warehouse zones, dock scheduling, and task assignments</p>
      </div>

      <!-- Tab Navigation -->
      <div class="card">
        <div class="border-b border-gray-200 dark:border-dark-700">
          <nav class="-mb-px flex space-x-8 px-6">
            <button *ngFor="let tab of tabs" 
                    (click)="activeTab = tab.id"
                    [class]="getTabClass(tab.id)"
                    class="py-4 px-1 border-b-2 font-medium text-sm transition-colors flex items-center">
              <lucide-icon [img]="tab.icon" size="18" class="mr-2"></lucide-icon>
              {{ tab.name }}
            </button>
          </nav>
        </div>

        <!-- Zone Management Tab -->
        <app-warehouse-operations-zone-management
          *ngIf="activeTab === 'zones'" />

        <!-- Dock Scheduling Tab -->
        <app-warehouse-operations-dock-scheduling
          *ngIf="activeTab === 'scheduling'" />

        <!-- Task Assignment Tab -->
        <app-warehouse-operations-task-assignment
          *ngIf="activeTab === 'tasks'" />
      </div>
    </div>
  `
})
export class WarehouseOperationsComponent implements OnInit {
  activeTab = 'zones';

  tabs = [
    { id: 'zones', name: 'Zone Management', icon: MapPin },
    { id: 'scheduling', name: 'Dock Scheduling', icon: Calendar },
    { id: 'tasks', name: 'Task Assignment', icon: Users }
  ];

  constructor() {}

  ngOnInit(): void {}

  getTabClass(tabId: string): string {
    return tabId === this.activeTab
      ? 'border-primary-500 text-primary-600'
      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300';
  }
}