import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, of, throwError } from 'rxjs';
import { delay, map } from 'rxjs/operators';
import { AuthResponse, LoginCredentials, UserProfile } from '../types/interfaces';
import { MOCK_USERS } from './users.mock';

@Injectable({
  providedIn: 'root'
})
export class AuthService {
  private currentUserSubject = new BehaviorSubject<UserProfile | null>(null);
  public currentUser$ = this.currentUserSubject.asObservable();

  constructor() {
    const storedUser = localStorage.getItem('currentUser');
    if (storedUser) {
      this.currentUserSubject.next(JSON.parse(storedUser));
    }
  }

  login(credentials: LoginCredentials): Observable<AuthResponse> {
    const user = MOCK_USERS[credentials.username];
    
    if (user && credentials.password === 'password') {
      const authResponse: AuthResponse = {
        token: 'mock-jwt-token',
        refreshToken: 'mock-refresh-token',
        user: user,
        expiresAt: Date.now() + (24 * 60 * 60 * 1000) // 24 hours
      };

      localStorage.setItem('currentUser', JSON.stringify(user));
      localStorage.setItem('token', authResponse.token);
      this.currentUserSubject.next(user);

      return of(authResponse).pipe(delay(500));
    }

    return throwError(() => new Error('Invalid credentials')).pipe(delay(500));
  }

  logout(): void {
    localStorage.removeItem('currentUser');
    localStorage.removeItem('token');
    this.currentUserSubject.next(null);
  }

  get currentUserValue(): UserProfile | null {
    return this.currentUserSubject.value;
  }

  isAuthenticated(): boolean {
    return this.currentUserValue !== null;
  }

  hasRole(roleName: string): boolean {
    const user = this.currentUserValue;
    return user?.role.some(role => role.roleName === roleName) || false;
  }

  hasPermission(resource: string, action: string): boolean {
    // Simplified permission check - in real app, this would check against actual permissions
    return this.isAuthenticated();
  }
}