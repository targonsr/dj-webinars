import { Injectable, signal, computed } from '@angular/core';

export interface CargoListingFilters {
  searchTerm: string;
  category: string;
  status: string;
  zone: string;
}

@Injectable({
  providedIn: 'root'
})
export class CargoListingFiltersService {
  // Signals for filter state
  private _searchTerm = signal<string>('');
  private _category = signal<string>('');
  private _status = signal<string>('');
  private _zone = signal<string>('');

  // Computed signal that combines all filters
  filters = computed<CargoListingFilters>(() => ({
    searchTerm: this._searchTerm(),
    category: this._category(),
    status: this._status(),
    zone: this._zone()
  }));

  // Individual filter getters
  get searchTerm() { return this._searchTerm.asReadonly(); }
  get category() { return this._category.asReadonly(); }
  get status() { return this._status.asReadonly(); }
  get zone() { return this._zone.asReadonly(); }

  // Filter setters
  setSearchTerm(searchTerm: string): void {
    this._searchTerm.set(searchTerm);
  }

  setCategory(category: string): void {
    this._category.set(category);
  }

  setStatus(status: string): void {
    this._status.set(status);
  }

  setZone(zone: string): void {
    this._zone.set(zone);
  }

  // Reset all filters
  resetFilters(): void {
    this._searchTerm.set('');
    this._category.set('');
    this._status.set('');
    this._zone.set('');
  }

  // Check if any filters are active
  hasActiveFilters = computed<boolean>(() => {
    const filters = this.filters();
    return !!(filters.searchTerm || filters.category || filters.status || filters.zone);
  });
}