import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InventoryItem } from '../types/interfaces';
import { LucideAngularModule, MapPin } from 'lucide-angular';

interface LocationHistory {
  location: string;
  details: string;
  movedDate: Date;
  duration: string;
}

@Component({
  selector: 'app-cargo-detail-location-history',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <div class="p-6">
      <h4 class="text-md font-medium text-gray-900 dark:text-white mb-4">Location History</h4>
      <div class="space-y-4">
        <div *ngFor="let location of mockLocationHistory" class="flex items-center justify-between p-4 bg-gray-50 dark:bg-dark-700 rounded-lg">
          <div class="flex items-center">
            <lucide-icon [img]="MapPinIcon" size="18" class="text-gray-400 mr-3"></lucide-icon>
            <div>
              <p class="text-sm font-medium text-gray-900 dark:text-white">{{ location.location }}</p>
              <p class="text-xs text-gray-500 dark:text-gray-400">{{ location.details }}</p>
            </div>
          </div>
          <div class="text-right">
            <p class="text-sm text-gray-900 dark:text-white">{{ location.movedDate | date:'MMM d, y' }}</p>
            <p class="text-xs text-gray-500 dark:text-gray-400">{{ location.duration }}</p>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CargoDetailLocationHistoryComponent {
  // Signal-based input
  cargoItem = input<InventoryItem | null>(null);

  // Lucide icons
  MapPinIcon = MapPin;

  mockLocationHistory: LocationHistory[] = [
    {
      location: 'Zone A-1-R1-S3',
      details: 'Aisle 1, Rack 1, Shelf 3',
      movedDate: new Date('2025-01-10'),
      duration: '3 days (current)'
    },
    {
      location: 'Dock 2',
      details: 'Receiving dock for inspection',
      movedDate: new Date('2025-01-10'),
      duration: '30 minutes'
    }
  ];
}