import { Component, input } from '@angular/core';
import { CommonModule } from '@angular/common';
import { InventoryItem } from '../types/interfaces';
import { LucideAngularModule, FileText } from 'lucide-angular';

interface Document {
  name: string;
  type: string;
  size: string;
  uploadDate: Date;
}

@Component({
  selector: 'app-cargo-detail-documentation',
  standalone: true,
  imports: [CommonModule, LucideAngularModule],
  template: `
    <div class="p-6">
      <h4 class="text-md font-medium text-gray-900 dark:text-white mb-4">Documentation</h4>
      <div class="space-y-4">
        <div *ngFor="let doc of mockDocuments" class="flex items-center justify-between p-4 border border-gray-200 dark:border-dark-600 rounded-lg hover:bg-gray-50 dark:hover:bg-dark-700">
          <div class="flex items-center">
            <lucide-icon [img]="FileTextIcon" size="18" class="text-gray-400 mr-3"></lucide-icon>
            <div>
              <p class="text-sm font-medium text-gray-900 dark:text-white">{{ doc.name }}</p>
              <p class="text-xs text-gray-500 dark:text-gray-400">{{ doc.type }} • {{ doc.size }}</p>
            </div>
          </div>
          <div class="flex items-center space-x-2">
            <span class="text-xs text-gray-500 dark:text-gray-400">{{ doc.uploadDate | date:'MMM d, y' }}</span>
            <button class="text-primary-600 hover:text-primary-500 text-sm">Download</button>
          </div>
        </div>
      </div>
    </div>
  `
})
export class CargoDetailDocumentationComponent {
  // Signal-based input
  cargoItem = input<InventoryItem | null>(null);

  // Lucide icons
  FileTextIcon = FileText;

  mockDocuments: Document[] = [
    {
      name: 'Shipping Manifest',
      type: 'PDF',
      size: '2.4 MB',
      uploadDate: new Date('2025-01-10')
    },
    {
      name: 'Quality Inspection Report',
      type: 'PDF',
      size: '1.8 MB',
      uploadDate: new Date('2025-01-10')
    },
    {
      name: 'Insurance Certificate',
      type: 'PDF',
      size: '0.9 MB',
      uploadDate: new Date('2025-01-10')
    }
  ];
}