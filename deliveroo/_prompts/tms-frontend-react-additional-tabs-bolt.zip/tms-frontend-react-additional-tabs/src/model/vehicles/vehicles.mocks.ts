import { Vehicle } from './vehicle.types';

export const sampleVehicles: Vehicle[] = [
  {
    id: 'vehicle-001',
    plateNumber: 'WA-LOG 2024',
    make: 'Mercedes-Benz',
    model: 'Actros 1851',
    year: 2022,
    type: 'standard',
    status: 'active',
    mileage: 125000,
    capacity: {
      weight: 26,
      volume: 90
    },
    cargoTypes: ['ogólne', 'paletowe', 'suche'],
    currentDriver: 'Jan Kowalski',
    currentLocation: {
      lat: 52.2297,
      lng: 21.0122,
      address: 'Centrum Dystrybucji Warszawa',
      lastUpdate: new Date()
    },
    ownership: {
      type: 'owned',
      purchaseDate: new Date(2022, 2, 15),
      purchasePrice: 480000
    },
    documents: [
      {
        id: 'doc-001-1',
        type: 'registration',
        number: 'REJ-WA-LOG-2024',
        issueDate: new Date(2022, 2, 15),
        expiryDate: new Date(2025, 2, 15),
        issuingAuthority: 'Wydział Komunikacji Warszawa'
      },
      {
        id: 'doc-001-2',
        type: 'insurance',
        number: 'UB-001-2024',
        issueDate: new Date(2024, 0, 1),
        expiryDate: new Date(2025, 0, 1),
        issuingAuthority: 'PZU Ubezpieczenia'
      },
      {
        id: 'doc-001-3',
        type: 'inspection',
        number: 'PKD-001-2024',
        issueDate: new Date(2024, 5, 10),
        expiryDate: new Date(2025, 5, 10),
        issuingAuthority: 'Stacja Kontroli Pojazdów'
      }
    ],
    maintenanceHistory: [
      {
        id: 'maint-001-1',
        date: new Date(2024, 10, 15),
        type: 'routine',
        description: 'Przegląd okresowy - wymiana oleju, filtrów',
        cost: 1800,
        mileage: 124500,
        duration: 3,
        serviceProvider: 'Serwis Mercedes Warszawa',
        technician: 'Marek Kowalczyk',
        status: 'completed',
        notes: 'Wszystkie systemy sprawdzone, brak usterek'
      },
      {
        id: 'maint-001-2',
        date: new Date(2024, 9, 8),
        type: 'repair',
        description: 'Wymiana klocków hamulcowych',
        cost: 2720,
        mileage: 123800,
        duration: 4,
        serviceProvider: 'Serwis Mercedes Warszawa',
        technician: 'Anna Nowak',
        status: 'completed',
        notes: 'Wymieniono przednie klocki hamulcowe, płyn hamulcowy'
      },
      {
        id: 'maint-001-3',
        date: new Date(2024, 8, 22),
        type: 'inspection',
        description: 'Roczny przegląd techniczny',
        cost: 480,
        mileage: 123200,
        duration: 2,
        serviceProvider: 'Stacja Kontroli Pojazdów',
        technician: 'Piotr Wiśniewski',
        status: 'completed',
        notes: 'Przegląd zaliczony bez usterek'
      }
    ],
    maintenanceTasks: [
      {
        id: 'task-001-1',
        description: 'Wymiana filtra powietrza',
        dueDate: new Date(2024, 11, 30),
        priority: 'medium',
        estimatedCost: 340,
        estimatedDuration: 1,
        status: 'pending',
        assignedTo: 'Marek Kowalczyk',
        notes: 'Wymiana zgodnie z przebiegiem'
      },
      {
        id: 'task-001-2',
        description: 'Rotacja i kontrola opon',
        dueDate: new Date(2025, 0, 15),
        priority: 'low',
        estimatedCost: 480,
        estimatedDuration: 2,
        status: 'pending',
        assignedTo: 'Anna Nowak',
        notes: 'Regularna konserwacja opon'
      }
    ]
  },
  {
    id: 'vehicle-002',
    plateNumber: 'GD-EX 1234',
    make: 'Volvo',
    model: 'FH16 750',
    year: 2021,
    type: 'tir',
    status: 'in-transit',
    mileage: 180000,
    capacity: {
      weight: 40,
      volume: 120
    },
    cargoTypes: ['ogólne', 'paletowe', 'międzynarodowe'],
    currentDriver: 'Maria Nowak',
    currentLocation: {
      lat: 54.3520,
      lng: 18.6466,
      address: 'A1 koło Gdańska',
      lastUpdate: new Date()
    },
    ownership: {
      type: 'leased',
      leaseStart: new Date(2021, 5, 1),
      leaseEnd: new Date(2026, 5, 1),
      monthlyPayment: 11200,
      leasingCompany: 'Volvo Financial Services'
    },
    documents: [
      {
        id: 'doc-002-1',
        type: 'registration',
        number: 'REJ-GD-EX-1234',
        issueDate: new Date(2021, 5, 1),
        expiryDate: new Date(2024, 5, 1),
        issuingAuthority: 'Wydział Komunikacji Gdańsk'
      },
      {
        id: 'doc-002-2',
        type: 'insurance',
        number: 'UB-002-2024',
        issueDate: new Date(2024, 0, 1),
        expiryDate: new Date(2025, 0, 1),
        issuingAuthority: 'Warta Ubezpieczenia'
      },
      {
        id: 'doc-002-3',
        type: 'tir-carnet',
        number: 'TIR-002-2024',
        issueDate: new Date(2024, 2, 1),
        expiryDate: new Date(2025, 2, 1),
        issuingAuthority: 'Polski Związek Motorowy'
      }
    ],
    maintenanceHistory: [
      {
        id: 'maint-002-1',
        date: new Date(2024, 10, 20),
        type: 'routine',
        description: 'Główny serwis - 180 tys. km',
        cost: 4800,
        mileage: 180000,
        duration: 8,
        serviceProvider: 'Serwis Volvo Gdańsk',
        technician: 'Erik Larsson',
        status: 'completed',
        notes: 'Kompletny serwis silnika, wymiana wszystkich płynów'
      },
      {
        id: 'maint-002-2',
        date: new Date(2024, 8, 15),
        type: 'repair',
        description: 'Naprawa skrzyni biegów',
        cost: 10000,
        mileage: 178500,
        duration: 12,
        serviceProvider: 'Serwis Volvo Gdańsk',
        technician: 'Erik Larsson',
        status: 'completed',
        notes: 'Wymiana sprzęgła skrzyni, test OK'
      }
    ],
    maintenanceTasks: [
      {
        id: 'task-002-1',
        description: 'Wymiana filtra kabinowego',
        dueDate: new Date(2024, 11, 25),
        priority: 'low',
        estimatedCost: 180,
        estimatedDuration: 0.5,
        status: 'pending',
        assignedTo: 'Erik Larsson'
      },
      {
        id: 'task-002-2',
        description: 'Kontrola systemu AdBlue',
        dueDate: new Date(2025, 0, 10),
        priority: 'medium',
        estimatedCost: 600,
        estimatedDuration: 2,
        status: 'pending',
        assignedTo: 'Erik Larsson',
        notes: 'Regularna konserwacja systemu AdBlue'
      }
    ]
  },
  {
    id: 'vehicle-003',
    plateNumber: 'PO-VW 5678',
    make: 'Scania',
    model: 'R 450',
    year: 2020,
    type: 'refrigerated',
    status: 'maintenance',
    mileage: 220000,
    capacity: {
      weight: 24,
      volume: 80
    },
    cargoTypes: ['chłodnicze', 'mrożone', 'farmaceutyczne'],
    currentDriver: 'Tomasz Wiśniewski',
    currentLocation: {
      lat: 52.4064,
      lng: 16.9252,
      address: 'Serwis Scania Poznań',
      lastUpdate: new Date()
    },
    ownership: {
      type: 'financed',
      loanAmount: 380000,
      monthlyPayment: 7400,
      loanStart: new Date(2020, 8, 1),
      loanEnd: new Date(2025, 8, 1),
      bank: 'PKO Bank Polski'
    },
    documents: [
      {
        id: 'doc-003-1',
        type: 'registration',
        number: 'REJ-PO-VW-5678',
        issueDate: new Date(2020, 8, 1),
        expiryDate: new Date(2023, 8, 1),
        issuingAuthority: 'Wydział Komunikacji Poznań'
      },
      {
        id: 'doc-003-2',
        type: 'insurance',
        number: 'UB-003-2024',
        issueDate: new Date(2024, 0, 1),
        expiryDate: new Date(2025, 0, 1),
        issuingAuthority: 'Generali Ubezpieczenia'
      },
      {
        id: 'doc-003-3',
        type: 'adr',
        number: 'ADR-003-2024',
        issueDate: new Date(2024, 3, 1),
        expiryDate: new Date(2025, 3, 1),
        issuingAuthority: 'Urząd Transportu Drogowego'
      }
    ],
    maintenanceHistory: [
      {
        id: 'maint-003-1',
        date: new Date(2024, 10, 25),
        type: 'repair',
        description: 'Naprawa agregatu chłodniczego',
        cost: 12800,
        mileage: 220000,
        duration: 16,
        serviceProvider: 'Serwis Carrier Poznań',
        technician: 'Jan Chłodny',
        status: 'in-progress',
        notes: 'Wymiana sprężarki w toku'
      },
      {
        id: 'maint-003-2',
        date: new Date(2024, 9, 10),
        type: 'routine',
        description: 'Przegląd okresowy i kontrola',
        cost: 3400,
        mileage: 218500,
        duration: 6,
        serviceProvider: 'Serwis Scania Poznań',
        technician: 'Sven Andersson',
        status: 'completed',
        notes: 'Wszystkie systemy OK oprócz agregatu'
      }
    ],
    maintenanceTasks: [
      {
        id: 'task-003-1',
        description: 'Dokończenie naprawy agregatu chłodniczego',
        dueDate: new Date(2024, 10, 28),
        priority: 'urgent',
        estimatedCost: 12800,
        estimatedDuration: 16,
        status: 'in-progress',
        assignedTo: 'Jan Chłodny',
        notes: 'Krytyczne dla transportu chłodniczego'
      },
      {
        id: 'task-003-2',
        description: 'Kalibracja systemu monitoringu temperatury',
        dueDate: new Date(2024, 11, 5),
        priority: 'high',
        estimatedCost: 800,
        estimatedDuration: 2,
        status: 'pending',
        assignedTo: 'Jan Chłodny',
        notes: 'Wymagane po naprawie chłodzenia'
      }
    ]
  },
  {
    id: 'vehicle-004',
    plateNumber: 'LD-SIE 9012',
    make: 'MAN',
    model: 'TGX 18.500',
    year: 2023,
    type: 'hazmat',
    status: 'active',
    mileage: 45000,
    capacity: {
      weight: 26,
      volume: 85
    },
    cargoTypes: ['materiały-niebezpieczne', 'chemikalia', 'towary-niebezpieczne'],
    currentDriver: 'Agnieszka Wójcik',
    currentLocation: {
      lat: 51.7592,
      lng: 19.4560,
      address: 'Zakład Chemiczny Łódź',
      lastUpdate: new Date()
    },
    ownership: {
      type: 'owned',
      purchaseDate: new Date(2023, 1, 10),
      purchasePrice: 540000
    },
    documents: [
      {
        id: 'doc-004-1',
        type: 'registration',
        number: 'REJ-LD-SIE-9012',
        issueDate: new Date(2023, 1, 10),
        expiryDate: new Date(2026, 1, 10),
        issuingAuthority: 'Wydział Komunikacji Łódź'
      },
      {
        id: 'doc-004-2',
        type: 'insurance',
        number: 'UB-004-2024',
        issueDate: new Date(2024, 0, 1),
        expiryDate: new Date(2025, 0, 1),
        issuingAuthority: 'Ergo Hestia Ubezpieczenia'
      },
      {
        id: 'doc-004-3',
        type: 'adr',
        number: 'ADR-004-2024',
        issueDate: new Date(2024, 1, 1),
        expiryDate: new Date(2025, 1, 1),
        issuingAuthority: 'Urząd Transportu Drogowego'
      },
      {
        id: 'doc-004-4',
        type: 'hazmat-permit',
        number: 'MAT-004-2024',
        issueDate: new Date(2024, 0, 15),
        expiryDate: new Date(2025, 0, 15),
        issuingAuthority: 'Główny Inspektorat Transportu Drogowego'
      }
    ],
    maintenanceHistory: [
      {
        id: 'maint-004-1',
        date: new Date(2024, 9, 5),
        type: 'routine',
        description: 'Pierwszy główny przegląd',
        cost: 2600,
        mileage: 40000,
        duration: 4,
        serviceProvider: 'Serwis MAN Łódź',
        technician: 'Wolfgang Bauer',
        status: 'completed',
        notes: 'Pojazd w doskonałym stanie'
      },
      {
        id: 'maint-004-2',
        date: new Date(2024, 6, 20),
        type: 'inspection',
        description: 'Kontrola wyposażenia do materiałów niebezpiecznych',
        cost: 1200,
        mileage: 35000,
        duration: 3,
        serviceProvider: 'Serwis Kontroli Materiałów Niebezpiecznych',
        technician: 'Dr. Bezpieczeństwo Chemiczne',
        status: 'completed',
        notes: 'Całe wyposażenie bezpieczeństwa certyfikowane'
      }
    ],
    maintenanceTasks: [
      {
        id: 'task-004-1',
        description: 'Roczna certyfikacja wyposażenia do materiałów niebezpiecznych',
        dueDate: new Date(2025, 6, 20),
        priority: 'high',
        estimatedCost: 1400,
        estimatedDuration: 3,
        status: 'pending',
        assignedTo: 'Dr. Bezpieczeństwo Chemiczne',
        notes: 'Wymagana roczna certyfikacja bezpieczeństwa'
      }
    ]
  },
  {
    id: 'vehicle-005',
    plateNumber: 'WR-DHL 3456',
    make: 'DAF',
    model: 'XF 480',
    year: 2021,
    type: 'container',
    status: 'active',
    mileage: 160000,
    capacity: {
      weight: 44,
      volume: 140
    },
    cargoTypes: ['kontenery', 'intermodalne', 'ogólne'],
    currentDriver: 'Paweł Kaczmarek',
    currentLocation: {
      lat: 51.1079,
      lng: 17.0385,
      address: 'Terminal Kontenerowy Wrocław',
      lastUpdate: new Date()
    },
    ownership: {
      type: 'rented',
      rentalStart: new Date(2024, 0, 1),
      rentalEnd: new Date(2024, 11, 31),
      monthlyPayment: 8800,
      rentalCompany: 'DAF Rental Services'
    },
    documents: [
      {
        id: 'doc-005-1',
        type: 'registration',
        number: 'REJ-WR-DHL-3456',
        issueDate: new Date(2021, 3, 15),
        expiryDate: new Date(2024, 3, 15),
        issuingAuthority: 'Wydział Komunikacji Wrocław'
      },
      {
        id: 'doc-005-2',
        type: 'insurance',
        number: 'UB-005-2024',
        issueDate: new Date(2024, 0, 1),
        expiryDate: new Date(2025, 0, 1),
        issuingAuthority: 'Compensa Ubezpieczenia'
      }
    ],
    maintenanceHistory: [
      {
        id: 'maint-005-1',
        date: new Date(2024, 8, 30),
        type: 'routine',
        description: 'Przegląd okresowy',
        cost: 3000,
        mileage: 158000,
        duration: 5,
        serviceProvider: 'Serwis DAF Wrocław',
        technician: 'Jan van der Berg',
        status: 'completed',
        notes: 'Wszystkie systemy działają prawidłowo'
      }
    ],
    maintenanceTasks: [
      {
        id: 'task-005-1',
        description: 'Kontrola mechanizmu podnoszenia kontenerów',
        dueDate: new Date(2024, 11, 15),
        priority: 'medium',
        estimatedCost: 800,
        estimatedDuration: 2,
        status: 'pending',
        assignedTo: 'Jan van der Berg',
        notes: 'Roczna kontrola bezpieczeństwa obsługi kontenerów'
      }
    ]
  },
  {
    id: 'vehicle-006',
    plateNumber: 'KR-TAN 7890',
    make: 'Iveco',
    model: 'Stralis NP 460',
    year: 2022,
    type: 'tanker',
    status: 'out-of-service',
    mileage: 95000,
    capacity: {
      weight: 40,
      volume: 35
    },
    cargoTypes: ['płyny', 'paliwo', 'chemikalia'],
    currentLocation: {
      lat: 50.0647,
      lng: 19.9450,
      address: 'Serwis Kraków',
      lastUpdate: new Date()
    },
    ownership: {
      type: 'leased',
      leaseStart: new Date(2022, 4, 1),
      leaseEnd: new Date(2027, 4, 1),
      monthlyPayment: 12800,
      leasingCompany: 'Iveco Capital'
    },
    documents: [
      {
        id: 'doc-006-1',
        type: 'registration',
        number: 'REJ-KR-TAN-7890',
        issueDate: new Date(2022, 4, 1),
        expiryDate: new Date(2025, 4, 1),
        issuingAuthority: 'Wydział Komunikacji Kraków'
      },
      {
        id: 'doc-006-2',
        type: 'insurance',
        number: 'UB-006-2024',
        issueDate: new Date(2024, 0, 1),
        expiryDate: new Date(2025, 0, 1),
        issuingAuthority: 'Uniqa Ubezpieczenia'
      },
      {
        id: 'doc-006-3',
        type: 'adr',
        number: 'ADR-006-2024',
        issueDate: new Date(2024, 2, 1),
        expiryDate: new Date(2025, 2, 1),
        issuingAuthority: 'Urząd Transportu Drogowego'
      }
    ],
    maintenanceHistory: [
      {
        id: 'maint-006-1',
        date: new Date(2024, 10, 22),
        type: 'emergency',
        description: 'Awaria silnika - główna naprawa',
        cost: 34000,
        mileage: 95000,
        duration: 48,
        serviceProvider: 'Serwis Iveco Kraków',
        technician: 'Marco Rossi',
        status: 'in-progress',
        notes: 'Wymagana przebudowa silnika, części w zamówieniu'
      },
      {
        id: 'maint-006-2',
        date: new Date(2024, 7, 15),
        type: 'inspection',
        description: 'Test ciśnienia zbiornika',
        cost: 1800,
        mileage: 92000,
        duration: 4,
        serviceProvider: 'Serwis Kontroli Zbiorników',
        technician: 'Inspektor Bezpieczeństwa',
        status: 'completed',
        notes: 'Zbiornik certyfikowany na kolejny rok'
      }
    ],
    maintenanceTasks: [
      {
        id: 'task-006-1',
        description: 'Dokończenie przebudowy silnika',
        dueDate: new Date(2024, 11, 1),
        priority: 'urgent',
        estimatedCost: 34000,
        estimatedDuration: 48,
        status: 'in-progress',
        assignedTo: 'Marco Rossi',
        notes: 'Krytyczna naprawa - pojazd poza eksploatacją'
      },
      {
        id: 'task-006-2',
        description: 'Kontrola bezpieczeństwa po naprawie',
        dueDate: new Date(2024, 11, 5),
        priority: 'urgent',
        estimatedCost: 800,
        estimatedDuration: 3,
        status: 'pending',
        assignedTo: 'Inspektor Bezpieczeństwa',
        notes: 'Wymagane przed powrotem do eksploatacji'
      }
    ]
  }
];