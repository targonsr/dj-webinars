import { Driver, DriverRoute, CalendarEvent } from './driver.types';

const generateDriverRoutes = (driverId: string): DriverRoute[] => {
  const routes: DriverRoute[] = [];
  const now = new Date();
  
  // Generate routes for the past 3 months
  for (let i = 0; i < 12; i++) {
    const startDate = new Date(now.getTime() - (i * 7 + Math.random() * 3) * 24 * 60 * 60 * 1000);
    const endDate = new Date(startDate.getTime() + (1 + Math.random() * 2) * 24 * 60 * 60 * 1000);
    
    const origins = ['Warszawa', 'Kraków', 'Gdańsk', 'Wrocław', 'Poznań'];
    const destinations = ['Łódź', 'Szczecin', 'Lublin', 'Katowice', 'Bydgoszcz'];
    
    const origin = origins[Math.floor(Math.random() * origins.length)];
    const destination = destinations[Math.floor(Math.random() * destinations.length)];
    
    routes.push({
      id: `route-${driverId}-${i}`,
      name: `${origin} → ${destination}`,
      startDate,
      endDate,
      origin,
      destination,
      distance: Math.floor(Math.random() * 800 + 200),
      status: i === 0 ? 'active' : i < 3 ? 'completed' : 'completed',
      points: [
        {
          lat: 52.2297 + (Math.random() - 0.5) * 2,
          lng: 21.0122 + (Math.random() - 0.5) * 4,
          timestamp: startDate,
          type: 'start',
          name: origin
        },
        {
          lat: 51.7592 + (Math.random() - 0.5) * 2,
          lng: 19.4560 + (Math.random() - 0.5) * 4,
          timestamp: new Date(startDate.getTime() + 4 * 60 * 60 * 1000),
          type: 'rest',
          name: 'Miejsce Odpoczynku'
        },
        {
          lat: 50.0647 + (Math.random() - 0.5) * 2,
          lng: 19.9450 + (Math.random() - 0.5) * 4,
          timestamp: endDate,
          type: 'end',
          name: destination
        }
      ]
    });
  }
  
  return routes.sort((a, b) => b.startDate.getTime() - a.startDate.getTime());
};

const generateCalendarEvents = (routes: DriverRoute[]): CalendarEvent[] => {
  const events: CalendarEvent[] = [];
  
  // Add route events
  routes.forEach(route => {
    events.push({
      id: `event-${route.id}`,
      title: `Trasa: ${route.name}`,
      start: route.startDate,
      end: route.endDate,
      type: 'route',
      description: `Trasa ${route.distance}km z ${route.origin} do ${route.destination}`,
      routeId: route.id
    });
  });
  
  // Add some sick leave and vacation events
  const now = new Date();
  events.push({
    id: 'sick-1',
    title: 'Zwolnienie Lekarskie',
    start: new Date(now.getTime() - 45 * 24 * 60 * 60 * 1000),
    end: new Date(now.getTime() - 43 * 24 * 60 * 60 * 1000),
    type: 'sick-leave',
    description: 'Zwolnienie medyczne'
  });
  
  events.push({
    id: 'vacation-1',
    title: 'Urlop Wypoczynkowy',
    start: new Date(now.getTime() - 20 * 24 * 60 * 60 * 1000),
    end: new Date(now.getTime() - 15 * 24 * 60 * 60 * 1000),
    type: 'vacation',
    description: 'Urlop letni'
  });
  
  return events;
};

export const sampleDrivers: Driver[] = [
  {
    id: 'driver-001',
    name: 'Jan Kowalski',
    email: 'jan.kowalski@gmail.com',
    phone: '+48 22 123 45 67',
    address: {
      street: 'ul. Marszałkowska 123',
      city: 'Warszawa',
      postalCode: '00-001',
      country: 'Polska'
    },
    contractType: 'full-time',
    salary: 7200,
    currency: 'PLN',
    licenseNumber: 'PL123456789',
    licenseExpiry: new Date(2026, 5, 15),
    hireDate: new Date(2020, 2, 1),
    currentLocation: {
      lat: 52.2297,
      lng: 21.0122,
      address: 'A2 koło Warszawy',
      lastUpdate: new Date()
    },
    status: 'on-route',
    emergencyContact: {
      name: 'Anna Kowalska',
      phone: '+48 22 987 65 43',
      relationship: 'Żona'
    },
    routes: [],
    calendarEvents: []
  },
  {
    id: 'driver-002',
    name: 'Maria Nowak',
    email: 'maria.nowak@onet.pl',
    phone: '+48 12 234 56 78',
    address: {
      street: 'ul. Floriańska 456',
      city: 'Kraków',
      postalCode: '31-021',
      country: 'Polska'
    },
    contractType: 'full-time',
    salary: 7800,
    currency: 'PLN',
    licenseNumber: 'PL987654321',
    licenseExpiry: new Date(2025, 11, 30),
    hireDate: new Date(2019, 8, 15),
    currentLocation: {
      lat: 50.0647,
      lng: 19.9450,
      address: 'Terminal Portowy Kraków',
      lastUpdate: new Date()
    },
    status: 'active',
    emergencyContact: {
      name: 'Piotr Nowak',
      phone: '+48 12 345 67 89',
      relationship: 'Ojciec'
    },
    routes: [],
    calendarEvents: []
  },
  {
    id: 'driver-003',
    name: 'Tomasz Wiśniewski',
    email: 'tomasz.wisniewski@wp.pl',
    phone: '+48 58 345 67 89',
    address: {
      street: 'ul. Długa 789',
      city: 'Gdańsk',
      postalCode: '80-827',
      country: 'Polska'
    },
    contractType: 'contractor',
    salary: 6500,
    currency: 'PLN',
    licenseNumber: 'PL456789123',
    licenseExpiry: new Date(2027, 3, 20),
    hireDate: new Date(2021, 6, 10),
    currentLocation: {
      lat: 54.3520,
      lng: 18.6466,
      address: 'Centrum Logistyczne Gdańsk',
      lastUpdate: new Date()
    },
    status: 'resting',
    emergencyContact: {
      name: 'Katarzyna Wiśniewska',
      phone: '+48 58 456 78 90',
      relationship: 'Siostra'
    },
    routes: [],
    calendarEvents: []
  },
  {
    id: 'driver-004',
    name: 'Agnieszka Wójcik',
    email: 'agnieszka.wojcik@interia.pl',
    phone: '+48 61 456 78 90',
    address: {
      street: 'ul. Święty Marcin 321',
      city: 'Poznań',
      postalCode: '61-806',
      country: 'Polska'
    },
    contractType: 'full-time',
    salary: 8000,
    currency: 'PLN',
    licenseNumber: 'PL789123456',
    licenseExpiry: new Date(2026, 8, 10),
    hireDate: new Date(2018, 4, 20),
    currentLocation: {
      lat: 52.4064,
      lng: 16.9252,
      address: 'Lotnisko Poznań-Ławica Cargo',
      lastUpdate: new Date()
    },
    status: 'on-route',
    emergencyContact: {
      name: 'Marek Wójcik',
      phone: '+48 61 567 89 01',
      relationship: 'Mąż'
    },
    routes: [],
    calendarEvents: []
  },
  {
    id: 'driver-005',
    name: 'Paweł Kaczmarek',
    email: 'pawel.kaczmarek@o2.pl',
    phone: '+48 71 567 89 01',
    address: {
      street: 'ul. Rynek 654',
      city: 'Wrocław',
      postalCode: '50-101',
      country: 'Polska'
    },
    contractType: 'contractor',
    salary: 6200,
    currency: 'PLN',
    licenseNumber: 'PL321654987',
    licenseExpiry: new Date(2025, 1, 5),
    hireDate: new Date(2022, 0, 15),
    status: 'off-duty',
    emergencyContact: {
      name: 'Magdalena Kaczmarek',
      phone: '+48 71 678 90 12',
      relationship: 'Córka'
    },
    routes: [],
    calendarEvents: []
  }
];

// Generate routes and calendar events for each driver
sampleDrivers.forEach(driver => {
  driver.routes = generateDriverRoutes(driver.id);
  driver.calendarEvents = generateCalendarEvents(driver.routes);
});