import { Shipment, RouteData, RoutePoint, Vehicle } from './logistics.types';

const createSampleRoute = (
  id: string,
  name: string,
  points: Omit<RoutePoint, 'id'>[],
  vehicle: Vehicle,
  status: RouteData['status'] = 'active'
): RouteData => {
  const routePoints: RoutePoint[] = points.map((point, index) => ({
    ...point,
    id: `${id}-point-${index + 1}`
  }));

  // Calculate basic metrics
  const totalDistance = Math.random() * 800 + 200; // 200-1000 km
  const estimatedDuration = Math.floor(totalDistance / 80 * 60); // Assuming 80 km/h average

  const startTime = new Date(Date.now() + Math.random() * 24 * 60 * 60 * 1000);
  const estimatedCompletion = new Date(startTime.getTime() + estimatedDuration * 60 * 1000);

  return {
    id,
    name,
    points: routePoints,
    vehicle,
    totalDistance,
    estimatedDuration,
    status,
    startTime,
    estimatedCompletion
  };
};

export const sampleShipments: Shipment[] = [
  {
    id: 'ship-001',
    name: 'Warszawa → Kraków Express',
    customer: 'Fabryka BMW',
    priority: 'high',
    createdAt: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() + 1 * 24 * 60 * 60 * 1000),
    route: createSampleRoute(
      'route-001',
      'Warszawa → Kraków Express',
      [
        {
          coordinates: { lat: 52.2297, lng: 21.0122 }, // Warszawa
          type: 'pickup',
          name: 'Centrum Dystrybucji Warszawa',
          address: 'ul. Marszałkowska 1, Warszawa, Polska',
          estimatedArrival: new Date(Date.now() + 2 * 60 * 60 * 1000),
          estimatedDeparture: new Date(Date.now() + 3 * 60 * 60 * 1000),
          duration: 60,
          notes: 'Główne miejsce odbioru - 15 palet'
        },
        {
          coordinates: { lat: 51.7592, lng: 19.4560 }, // Łódź
          type: 'rest',
          name: 'Miejsce Odpoczynku Łódź',
          address: 'MOP A2, Łódź, Polska',
          estimatedArrival: new Date(Date.now() + 6 * 60 * 60 * 1000),
          estimatedDeparture: new Date(Date.now() + 6.75 * 60 * 60 * 1000),
          duration: 45,
          notes: 'Obowiązkowy odpoczynek kierowcy'
        },
        {
          coordinates: { lat: 50.0647, lng: 19.9450 }, // Kraków
          type: 'delivery',
          name: 'Fabryka BMW Kraków',
          address: 'ul. Wadowicka 130, Kraków, Polska',
          estimatedArrival: new Date(Date.now() + 10 * 60 * 60 * 1000),
          duration: 90,
          notes: 'Dostawa końcowa - 15 palet, rampa 7'
        }
      ],
      {
        id: 'truck-001',
        coordinates: { lat: 52.2, lng: 21.0 },
        heading: 180,
        speed: 85,
        driver: 'Jan Kowalski',
        plateNumber: 'WA-LOG 2024',
        lastUpdate: new Date()
      },
      'active'
    )
  },
  {
    id: 'ship-002',
    name: 'Gdańsk → Wrocław Trasa',
    customer: 'Mercedes-Benz Polska',
    priority: 'urgent',
    createdAt: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() + 0.5 * 24 * 60 * 60 * 1000),
    route: createSampleRoute(
      'route-002',
      'Gdańsk → Wrocław Trasa',
      [
        {
          coordinates: { lat: 54.3520, lng: 18.6466 }, // Gdańsk
          type: 'pickup',
          name: 'Terminal Portowy Gdańsk',
          address: 'ul. Portowa 1, Gdańsk, Polska',
          estimatedArrival: new Date(Date.now() + 1 * 60 * 60 * 1000),
          estimatedDeparture: new Date(Date.now() + 2 * 60 * 60 * 1000),
          duration: 60,
          notes: 'Odbiór kontenera - pilna dostawa'
        },
        {
          coordinates: { lat: 51.1079, lng: 17.0385 }, // Wrocław
          type: 'delivery',
          name: 'Fabryka Mercedes-Benz',
          address: 'ul. Żmigrodzka 120, Wrocław, Polska',
          estimatedArrival: new Date(Date.now() + 8 * 60 * 60 * 1000),
          duration: 45,
          notes: 'Dostawa do linii produkcyjnej'
        }
      ],
      {
        id: 'truck-002',
        coordinates: { lat: 54.3, lng: 18.6 },
        heading: 225,
        speed: 90,
        driver: 'Maria Nowak',
        plateNumber: 'GD-EX 1234',
        lastUpdate: new Date()
      },
      'active'
    )
  },
  {
    id: 'ship-003',
    name: 'Poznań → Lublin Multi-Stop',
    customer: 'Volkswagen Grupa',
    priority: 'medium',
    createdAt: new Date(Date.now() - 3 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() + 2 * 24 * 60 * 60 * 1000),
    route: createSampleRoute(
      'route-003',
      'Poznań → Lublin Multi-Stop',
      [
        {
          coordinates: { lat: 52.4064, lng: 16.9252 }, // Poznań
          type: 'pickup',
          name: 'Centrum Logistyczne Poznań',
          address: 'ul. Bukowska 1, Poznań, Polska',
          estimatedArrival: new Date(Date.now() + 4 * 60 * 60 * 1000),
          estimatedDeparture: new Date(Date.now() + 5 * 60 * 60 * 1000),
          duration: 60,
          notes: 'Odbiór części dla VW'
        },
        {
          coordinates: { lat: 51.2465, lng: 22.5684 }, // Lublin
          type: 'delivery',
          name: 'Fabryka VW Lublin',
          address: 'ul. Fabryczna 1, Lublin, Polska',
          estimatedArrival: new Date(Date.now() + 12 * 60 * 60 * 1000),
          duration: 75,
          notes: 'Dostawa precyzyjnych części'
        }
      ],
      {
        id: 'truck-003',
        coordinates: { lat: 52.4, lng: 16.9 },
        heading: 90,
        speed: 75,
        driver: 'Tomasz Wiśniewski',
        plateNumber: 'PO-VW 5678',
        lastUpdate: new Date()
      },
      'planned'
    )
  },
  {
    id: 'ship-004',
    name: 'Łódź → Katowice Express',
    customer: 'Siemens Polska',
    priority: 'high',
    createdAt: new Date(Date.now() - 0.5 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() + 1.5 * 24 * 60 * 60 * 1000),
    route: createSampleRoute(
      'route-004',
      'Łódź → Katowice Express',
      [
        {
          coordinates: { lat: 51.7592, lng: 19.4560 }, // Łódź
          type: 'pickup',
          name: 'Lotnisko Łódź Cargo',
          address: 'ul. Generała Stefana Roweckiego 33, Łódź, Polska',
          estimatedArrival: new Date(Date.now() + 3 * 60 * 60 * 1000),
          estimatedDeparture: new Date(Date.now() + 4 * 60 * 60 * 1000),
          duration: 60,
          notes: 'Odbiór sprzętu high-tech'
        },
        {
          coordinates: { lat: 50.2649, lng: 19.0238 }, // Katowice
          type: 'delivery',
          name: 'Siemens Centrala',
          address: 'ul. Żwirki i Wigury 1, Katowice, Polska',
          estimatedArrival: new Date(Date.now() + 7 * 60 * 60 * 1000),
          duration: 45,
          notes: 'Wrażliwy sprzęt - ostrożnie'
        }
      ],
      {
        id: 'truck-004',
        coordinates: { lat: 51.7, lng: 19.4 },
        heading: 135,
        speed: 80,
        driver: 'Agnieszka Wójcik',
        plateNumber: 'LD-SIE 9012',
        lastUpdate: new Date()
      },
      'delayed'
    )
  },
  {
    id: 'ship-005',
    name: 'Wrocław → Szczecin Zakończone',
    customer: 'DHL Express Polska',
    priority: 'low',
    createdAt: new Date(Date.now() - 5 * 24 * 60 * 60 * 1000),
    dueDate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000),
    route: createSampleRoute(
      'route-005',
      'Wrocław → Szczecin Zakończone',
      [
        {
          coordinates: { lat: 51.1079, lng: 17.0385 }, // Wrocław
          type: 'pickup',
          name: 'Hub DHL Wrocław',
          address: 'ul. Lotnicza 2, Wrocław, Polska',
          estimatedArrival: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000),
          estimatedDeparture: new Date(Date.now() - 2 * 24 * 60 * 60 * 1000 + 60 * 60 * 1000),
          duration: 60,
          notes: 'Odbiór paczek ekspresowych'
        },
        {
          coordinates: { lat: 53.4285, lng: 14.5528 }, // Szczecin
          type: 'delivery',
          name: 'Hub DHL Szczecin',
          address: 'ul. Portowa 1, Szczecin, Polska',
          estimatedArrival: new Date(Date.now() - 1.5 * 24 * 60 * 60 * 1000),
          duration: 30,
          notes: 'Transfer między hubami zakończony'
        }
      ],
      {
        id: 'truck-005',
        coordinates: { lat: 53.4, lng: 14.5 },
        heading: 0,
        speed: 0,
        driver: 'Paweł Kaczmarek',
        plateNumber: 'WR-DHL 3456',
        lastUpdate: new Date(Date.now() - 1 * 24 * 60 * 60 * 1000)
      },
      'completed'
    )
  }
];