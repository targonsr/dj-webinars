import React from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { Truck, Users, Route, FileText } from 'lucide-react';

export const Navigation: React.FC = () => {
  const location = useLocation();
  const navigate = useNavigate();

  const navItems = [
    {
      path: '/routes',
      label: 'Route Planner',
      icon: Route,
      description: 'Plan and manage shipment routes'
    },
    {
      path: '/drivers',
      label: 'Drivers',
      icon: Users,
      description: 'Manage driver information and schedules'
    },
    {
      path: '/vehicles',
      label: 'Vehicles',
      icon: Truck,
      description: 'Manage fleet vehicles and maintenance'
    },
    {
      path: '/documents',
      label: 'Documents',
      icon: FileText,
      description: 'Manage all company documents'
    }
  ];

  const isActive = (path: string) => {
    return location.pathname === path || location.pathname.startsWith(path + '/');
  };

  return (
    <nav className="bg-white shadow-sm border-b">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-3">
            <div className="bg-blue-600 p-2 rounded-lg">
              <Truck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-semibold text-gray-900">Deliveroo TMS</h1>
              <p className="text-sm text-gray-500">Transport Management System</p>
            </div>
          </div>
          
          <div className="flex items-center gap-1">
            {navItems.map((item) => {
              const Icon = item.icon;
              const active = isActive(item.path);
              
              return (
                <button
                  key={item.path}
                  onClick={() => navigate(item.path)}
                  className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-colors ${
                    active
                      ? 'bg-blue-100 text-blue-700 font-medium'
                      : 'text-gray-600 hover:text-gray-900 hover:bg-gray-100'
                  }`}
                  title={item.description}
                >
                  <Icon className="w-4 h-4" />
                  <span className="hidden sm:inline">{item.label}</span>
                </button>
              );
            })}
          </div>
        </div>
      </div>
    </nav>
  );
};