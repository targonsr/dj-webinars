import React, { useState } from 'react';
import { Vehicle, MaintenanceRecord, MaintenanceTask } from '../../types/vehicle';
import { 
  ArrowLeft, Calendar, Clock, AlertTriangle, CheckCircle, 
  Wrench, DollarSign, User, FileText, Plus, Filter,
  TrendingUp, AlertCircle, Settings, MapPin
} from 'lucide-react';
import { formatDateTime, formatDate } from '../../utils/dateUtils';

interface VehicleMaintenanceProps {
  vehicle: Vehicle;
  onBack: () => void;
}

export const VehicleMaintenance: React.FC<VehicleMaintenanceProps> = ({ vehicle, onBack }) => {
  const [activeTab, setActiveTab] = useState<'overview' | 'history' | 'scheduled' | 'tasks'>('overview');
  const [showAddTask, setShowAddTask] = useState(false);
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'overdue' | 'completed'>('all');

  const getStatusColor = (status: MaintenanceRecord['status'] | MaintenanceTask['status']) => {
    const colors = {
      'completed': 'bg-green-100 text-green-800',
      'in-progress': 'bg-blue-100 text-blue-800',
      'pending': 'bg-yellow-100 text-yellow-800',
      'overdue': 'bg-red-100 text-red-800',
      'cancelled': 'bg-gray-100 text-gray-800'
    };
    return colors[status];
  };

  const getPriorityColor = (priority: MaintenanceTask['priority']) => {
    const colors = {
      'low': 'bg-gray-100 text-gray-700',
      'medium': 'bg-blue-100 text-blue-700',
      'high': 'bg-orange-100 text-orange-700',
      'urgent': 'bg-red-100 text-red-700'
    };
    return colors[priority];
  };

  const getMaintenanceTypeIcon = (type: MaintenanceRecord['type']) => {
    const icons = {
      'routine': <Settings className="w-4 h-4" />,
      'repair': <Wrench className="w-4 h-4" />,
      'inspection': <FileText className="w-4 h-4" />,
      'emergency': <AlertTriangle className="w-4 h-4" />
    };
    return icons[type];
  };

  const filteredTasks = vehicle.maintenanceTasks.filter(task => {
    if (filterStatus === 'all') return true;
    return task.status === filterStatus;
  });

  const upcomingTasks = vehicle.maintenanceTasks.filter(task => 
    task.status === 'pending' && new Date(task.dueDate) <= new Date(Date.now() + 30 * 24 * 60 * 60 * 1000)
  );

  const overdueTasks = vehicle.maintenanceTasks.filter(task => 
    task.status === 'pending' && new Date(task.dueDate) < new Date()
  );

  const totalMaintenanceCost = vehicle.maintenanceHistory.reduce((sum, record) => sum + record.cost, 0);
  const avgCostPerService = totalMaintenanceCost / vehicle.maintenanceHistory.length || 0;

  const renderOverview = () => (
    <div className="space-y-6">
      {/* Key Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white p-4 rounded-lg border">
          <div className="flex items-center gap-2 mb-2">
            <AlertTriangle className="w-5 h-5 text-red-500" />
            <span className="text-sm font-medium text-gray-600">Overdue Tasks</span>
          </div>
          <p className="text-2xl font-bold text-red-600">{overdueTasks.length}</p>
        </div>
        
        <div className="bg-white p-4 rounded-lg border">
          <div className="flex items-center gap-2 mb-2">
            <Clock className="w-5 h-5 text-orange-500" />
            <span className="text-sm font-medium text-gray-600">Upcoming (30 days)</span>
          </div>
          <p className="text-2xl font-bold text-orange-600">{upcomingTasks.length}</p>
        </div>
        
        <div className="bg-white p-4 rounded-lg border">
          <div className="flex items-center gap-2 mb-2">
            <DollarSign className="w-5 h-5 text-green-500" />
            <span className="text-sm font-medium text-gray-600">Total Cost (YTD)</span>
          </div>
          <p className="text-2xl font-bold text-green-600">€{totalMaintenanceCost.toLocaleString()}</p>
        </div>
        
        <div className="bg-white p-4 rounded-lg border">
          <div className="flex items-center gap-2 mb-2">
            <TrendingUp className="w-5 h-5 text-blue-500" />
            <span className="text-sm font-medium text-gray-600">Avg Cost/Service</span>
          </div>
          <p className="text-2xl font-bold text-blue-600">€{Math.round(avgCostPerService).toLocaleString()}</p>
        </div>
      </div>

      {/* Urgent Alerts */}
      {(overdueTasks.length > 0 || upcomingTasks.length > 0) && (
        <div className="bg-red-50 border border-red-200 rounded-lg p-4">
          <h3 className="font-semibold text-red-800 mb-3 flex items-center gap-2">
            <AlertCircle className="w-5 h-5" />
            Maintenance Alerts
          </h3>
          <div className="space-y-2">
            {overdueTasks.slice(0, 3).map(task => (
              <div key={task.id} className="flex items-center justify-between text-sm">
                <span className="text-red-700">{task.description}</span>
                <span className="text-red-600 font-medium">
                  Overdue by {Math.ceil((Date.now() - new Date(task.dueDate).getTime()) / (24 * 60 * 60 * 1000))} days
                </span>
              </div>
            ))}
            {upcomingTasks.slice(0, 2).map(task => (
              <div key={task.id} className="flex items-center justify-between text-sm">
                <span className="text-orange-700">{task.description}</span>
                <span className="text-orange-600 font-medium">
                  Due {formatDate(new Date(task.dueDate))}
                </span>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Recent Maintenance */}
      <div className="bg-white rounded-lg border">
        <div className="p-4 border-b">
          <h3 className="font-semibold text-gray-900">Recent Maintenance History</h3>
        </div>
        <div className="divide-y">
          {vehicle.maintenanceHistory.slice(0, 5).map(record => (
            <div key={record.id} className="p-4">
              <div className="flex items-center justify-between mb-2">
                <div className="flex items-center gap-2">
                  {getMaintenanceTypeIcon(record.type)}
                  <span className="font-medium">{record.description}</span>
                </div>
                <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(record.status)}`}>
                  {record.status.toUpperCase()}
                </span>
              </div>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm text-gray-600">
                <div>
                  <span className="font-medium">Date:</span> {formatDate(record.date)}
                </div>
                <div>
                  <span className="font-medium">Cost:</span> €{record.cost.toLocaleString()}
                </div>
                <div>
                  <span className="font-medium">Mileage:</span> {record.mileage.toLocaleString()} km
                </div>
                <div>
                  <span className="font-medium">Provider:</span> {record.serviceProvider}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );

  const renderHistory = () => (
    <div className="bg-white rounded-lg border">
      <div className="p-4 border-b">
        <h3 className="font-semibold text-gray-900">Complete Maintenance History</h3>
      </div>
      <div className="divide-y">
        {vehicle.maintenanceHistory.map(record => (
          <div key={record.id} className="p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className={`p-2 rounded-lg ${
                  record.type === 'emergency' ? 'bg-red-100' :
                  record.type === 'repair' ? 'bg-orange-100' :
                  record.type === 'inspection' ? 'bg-blue-100' :
                  'bg-green-100'
                }`}>
                  {getMaintenanceTypeIcon(record.type)}
                </div>
                <div>
                  <h4 className="font-medium text-gray-900">{record.description}</h4>
                  <p className="text-sm text-gray-500 capitalize">{record.type} maintenance</p>
                </div>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(record.status)}`}>
                {record.status.toUpperCase()}
              </span>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
              <div>
                <span className="text-gray-500">Date:</span>
                <p className="font-medium">{formatDate(record.date)}</p>
              </div>
              <div>
                <span className="text-gray-500">Cost:</span>
                <p className="font-medium text-green-600">€{record.cost.toLocaleString()}</p>
              </div>
              <div>
                <span className="text-gray-500">Mileage:</span>
                <p className="font-medium">{record.mileage.toLocaleString()} km</p>
              </div>
              <div>
                <span className="text-gray-500">Duration:</span>
                <p className="font-medium">{record.duration} hours</p>
              </div>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
              <div>
                <span className="text-gray-500">Service Provider:</span>
                <p className="font-medium">{record.serviceProvider}</p>
              </div>
              <div>
                <span className="text-gray-500">Technician:</span>
                <p className="font-medium">{record.technician}</p>
              </div>
            </div>
            
            {record.notes && (
              <div className="mt-3 p-3 bg-gray-50 rounded-lg">
                <span className="text-sm text-gray-500">Notes:</span>
                <p className="text-sm text-gray-700 mt-1">{record.notes}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  const renderScheduled = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-gray-900">Scheduled Maintenance Tasks</h3>
        <div className="flex items-center gap-2">
          <Filter className="w-4 h-4 text-gray-500" />
          <select
            value={filterStatus}
            onChange={(e) => setFilterStatus(e.target.value as any)}
            className="border border-gray-300 rounded-lg px-3 py-1 text-sm"
          >
            <option value="all">All Tasks</option>
            <option value="pending">Pending</option>
            <option value="overdue">Overdue</option>
            <option value="completed">Completed</option>
          </select>
        </div>
      </div>
      
      <div className="grid grid-cols-1 gap-4">
        {filteredTasks.map(task => (
          <div key={task.id} className="bg-white rounded-lg border p-4">
            <div className="flex items-center justify-between mb-3">
              <div className="flex items-center gap-3">
                <div className={`px-2 py-1 rounded text-xs font-medium ${getPriorityColor(task.priority)}`}>
                  {task.priority.toUpperCase()}
                </div>
                <h4 className="font-medium text-gray-900">{task.description}</h4>
              </div>
              <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(task.status)}`}>
                {task.status.toUpperCase()}
              </span>
            </div>
            
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm mb-3">
              <div>
                <span className="text-gray-500">Due Date:</span>
                <p className={`font-medium ${
                  new Date(task.dueDate) < new Date() ? 'text-red-600' : 'text-gray-900'
                }`}>
                  {formatDate(new Date(task.dueDate))}
                </p>
              </div>
              <div>
                <span className="text-gray-500">Est. Cost:</span>
                <p className="font-medium">€{task.estimatedCost.toLocaleString()}</p>
              </div>
              <div>
                <span className="text-gray-500">Est. Duration:</span>
                <p className="font-medium">{task.estimatedDuration} hours</p>
              </div>
              <div>
                <span className="text-gray-500">Assigned To:</span>
                <p className="font-medium">{task.assignedTo || 'Unassigned'}</p>
              </div>
            </div>
            
            {task.notes && (
              <div className="p-3 bg-gray-50 rounded-lg">
                <p className="text-sm text-gray-700">{task.notes}</p>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );

  const renderTasks = () => (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <h3 className="font-semibold text-gray-900">Maintenance Tasks</h3>
        <button
          onClick={() => setShowAddTask(true)}
          className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
        >
          <Plus className="w-4 h-4" />
          Add Task
        </button>
      </div>
      
      {showAddTask && (
        <div className="bg-white rounded-lg border p-4">
          <h4 className="font-medium text-gray-900 mb-4">Add New Maintenance Task</h4>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <input
              type="text"
              placeholder="Task description"
              className="border border-gray-300 rounded-lg px-3 py-2"
            />
            <select className="border border-gray-300 rounded-lg px-3 py-2">
              <option value="low">Low Priority</option>
              <option value="medium">Medium Priority</option>
              <option value="high">High Priority</option>
              <option value="urgent">Urgent Priority</option>
            </select>
            <input
              type="date"
              className="border border-gray-300 rounded-lg px-3 py-2"
            />
            <input
              type="number"
              placeholder="Estimated cost (€)"
              className="border border-gray-300 rounded-lg px-3 py-2"
            />
          </div>
          <div className="flex gap-2 mt-4">
            <button className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors">
              Save Task
            </button>
            <button
              onClick={() => setShowAddTask(false)}
              className="px-4 py-2 bg-gray-300 text-gray-700 rounded-lg hover:bg-gray-400 transition-colors"
            >
              Cancel
            </button>
          </div>
        </div>
      )}
      
      <div className="grid grid-cols-1 gap-4">
        {vehicle.maintenanceTasks.map(task => (
          <div key={task.id} className="bg-white rounded-lg border p-4">
            <div className="flex items-center justify-between mb-2">
              <h4 className="font-medium text-gray-900">{task.description}</h4>
              <div className="flex items-center gap-2">
                <span className={`px-2 py-1 rounded text-xs font-medium ${getPriorityColor(task.priority)}`}>
                  {task.priority.toUpperCase()}
                </span>
                <span className={`px-3 py-1 rounded-full text-sm font-medium ${getStatusColor(task.status)}`}>
                  {task.status.toUpperCase()}
                </span>
              </div>
            </div>
            <div className="text-sm text-gray-600">
              Due: {formatDate(new Date(task.dueDate))} • 
              Cost: €{task.estimatedCost.toLocaleString()} • 
              Duration: {task.estimatedDuration}h
            </div>
          </div>
        ))}
      </div>
    </div>
  );

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-6">
        <button
          onClick={onBack}
          className="flex items-center gap-2 text-blue-600 hover:text-blue-800 mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Vehicles
        </button>
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-gray-900">
              Vehicle Maintenance - {vehicle.plateNumber}
            </h2>
            <p className="text-gray-600">
              {vehicle.make} {vehicle.model} ({vehicle.year}) • {vehicle.mileage.toLocaleString()} km
            </p>
          </div>
          <div className="text-right">
            <div className="text-sm text-gray-500">Current Status</div>
            <span className={`px-3 py-1 rounded-full text-sm font-medium ${
              vehicle.status === 'active' ? 'bg-green-100 text-green-800' :
              vehicle.status === 'maintenance' ? 'bg-orange-100 text-orange-800' :
              'bg-gray-100 text-gray-800'
            }`}>
              {vehicle.status.toUpperCase()}
            </span>
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div className="border-b border-gray-200 mb-6">
        <nav className="flex space-x-8">
          {[
            { id: 'overview', label: 'Overview', icon: TrendingUp },
            { id: 'history', label: 'History', icon: FileText },
            { id: 'scheduled', label: 'Scheduled', icon: Calendar },
            { id: 'tasks', label: 'Tasks', icon: CheckCircle }
          ].map(({ id, label, icon: Icon }) => (
            <button
              key={id}
              onClick={() => setActiveTab(id as any)}
              className={`flex items-center gap-2 py-2 px-1 border-b-2 font-medium text-sm ${
                activeTab === id
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              }`}
            >
              <Icon className="w-4 h-4" />
              {label}
            </button>
          ))}
        </nav>
      </div>

      {/* Tab Content */}
      {activeTab === 'overview' && renderOverview()}
      {activeTab === 'history' && renderHistory()}
      {activeTab === 'scheduled' && renderScheduled()}
      {activeTab === 'tasks' && renderTasks()}
    </div>
  );
};