import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Vehicle } from '../../model/vehicles';
import { 
  Truck, Search, Filter, MapPin, User, Calendar, 
  Wrench, FileText, AlertTriangle, ExternalLink,
  Fuel, Package, Shield, Snowflake, Route, X
} from 'lucide-react';
import { formatDateTime } from '../../utils/dateUtils';
import { VehicleFilters } from './VehicleFilters';
import { VehicleTile } from './VehicleTile';

interface VehiclesListProps {
  vehicles: Vehicle[];
}

export const VehiclesList: React.FC<VehiclesListProps> = ({ vehicles }) => {
  const navigate = useNavigate();
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | Vehicle['status']>('all');
  const [typeFilter, setTypeFilter] = useState<'all' | Vehicle['type']>('all');

  const filteredVehicles = vehicles.filter(vehicle => {
    const matchesSearch = 
      vehicle.plateNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.make.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.model.toLowerCase().includes(searchTerm.toLowerCase()) ||
      vehicle.currentDriver?.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || vehicle.status === statusFilter;
    const matchesType = typeFilter === 'all' || vehicle.type === typeFilter;
    
    return matchesSearch && matchesStatus && matchesType;
  });

  const handleVehicleSelect = (vehicle: Vehicle, view: 'routes' | 'maintenance' | 'documents') => {
    if (view === 'documents') {
      navigate(`/documents?entityType=vehicle&entityId=${vehicle.id}`);
    } else if (view === 'routes') {
      navigate(`/routes?context=vehicle-routes&entityId=${vehicle.id}`);
    } else {
      navigate(`/vehicles/${vehicle.id}/service`);
    }
  };

  const handleClearFilters = () => {
    setSearchTerm('');
    setStatusFilter('all');
    setTypeFilter('all');
  };

  const hasActiveFilters = searchTerm !== '' || statusFilter !== 'all' || typeFilter !== 'all';

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
      <div className="mb-6">
        <h2 className="text-2xl font-bold text-gray-900">Fleet Management</h2>
        <p className="text-gray-600">Manage vehicles, maintenance, and documentation</p>
      </div>

      {/* Search and Filters */}
      <VehicleFilters
        searchTerm={searchTerm}
        statusFilter={statusFilter}
        typeFilter={typeFilter}
        onSearchChange={setSearchTerm}
        onStatusChange={setStatusFilter}
        onTypeChange={setTypeFilter}
        onClearFilters={handleClearFilters}
        hasActiveFilters={hasActiveFilters}
        resultCount={filteredVehicles.length}
      />

      {/* Vehicles Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6">
        {filteredVehicles.map((vehicle) => (
          <VehicleTile
            key={vehicle.id}
            vehicle={vehicle}
            onVehicleSelect={handleVehicleSelect}
          />
        ))}
      </div>

      {filteredVehicles.length === 0 && (
        <div className="text-center py-12">
          <Truck className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <h3 className="text-lg font-medium text-gray-900 mb-2">No vehicles found</h3>
          <p className="text-gray-500">Try adjusting your search criteria or filters.</p>
        </div>
      )}
    </div>
  );
};