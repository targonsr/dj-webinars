import React from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { QueryProvider } from './providers/QueryProvider';
import { Navigation } from './components/Navigation';
import { ErrorBoundary } from './components/common/ErrorBoundary';

// Route Components
import { RoutePlanner } from './pages/RoutePlanner';
import { DriversPage } from './pages/DriversPage';
import { DriverDetailsPage } from './pages/DriverDetailsPage';
import { DriverCalendarPage } from './pages/DriverCalendarPage';
import { VehiclesPage } from './pages/VehiclesPage';
import { VehicleServicePage } from './pages/VehicleServicePage';
import { DocumentsPage } from './pages/DocumentsPage';

function App() {
  return (
    <QueryProvider>
      <ErrorBoundary>
        <Router>
          <div className="min-h-screen bg-gray-50">
            <Navigation />
            
            <Routes>
              {/* Route Planner */}
              <Route path="/routes" element={<RoutePlanner />} />
              
              {/* Drivers */}
              <Route path="/drivers" element={<DriversPage />} />
              <Route path="/drivers/:id/details" element={<DriverDetailsPage />} />
              <Route path="/drivers/:id/calendar" element={<DriverCalendarPage />} />
              <Route path="/drivers/:id/routes" element={<Navigate to="/routes" replace />} />
              
              {/* Vehicles */}
              <Route path="/vehicles" element={<VehiclesPage />} />
              <Route path="/vehicles/:id/service" element={<VehicleServicePage />} />
              <Route path="/vehicles/:id/documents" element={<Navigate to="/documents" replace />} />
              <Route path="/vehicles/:id/routes" element={<Navigate to="/routes" replace />} />
              
              {/* Documents */}
              <Route path="/documents" element={<DocumentsPage />} />
              
              {/* Default redirect */}
              <Route path="/" element={<Navigate to="/routes" replace />} />
              <Route path="*" element={<Navigate to="/routes" replace />} />
            </Routes>
          </div>
        </Router>
      </ErrorBoundary>
    </QueryProvider>
  );
}

export default App;