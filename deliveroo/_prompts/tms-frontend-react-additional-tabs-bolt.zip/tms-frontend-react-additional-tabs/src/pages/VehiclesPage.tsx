import React from 'react';
import { VehiclesList } from '../components/vehicles/VehiclesList';
import { LoadingPage, ErrorMessage } from '../components/common';
import { useVehiclesList } from '../hooks/queries';

export const VehiclesPage: React.FC = () => {
  const { data: vehicles = [], isLoading, error, refetch } = useVehiclesList();

  const handleRetry = () => {
    refetch();
  };

  if (isLoading) {
    return <LoadingPage />;
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <ErrorMessage 
          error={error instanceof Error ? error.message : 'Failed to load vehicles'} 
          onRetry={handleRetry} 
        />
      </div>
    );
  }

  return <VehiclesList vehicles={vehicles} />;
};