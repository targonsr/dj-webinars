import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { VehicleMaintenance } from '../components/vehicles/VehicleMaintenance';
import { LoadingPage, ErrorMessage } from '../components/common';
import { useVehicleDetails } from '../hooks/queries';

export const VehicleServicePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  
  const { data: vehicle, isLoading, error, refetch } = useVehicleDetails(id!);

  const handleBack = () => {
    navigate('/vehicles');
  };

  if (!id) {
    navigate('/vehicles');
    return null;
  }

  if (isLoading) {
    return <LoadingPage />;
  }

  if (error) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <ErrorMessage 
          error={error instanceof Error ? error.message : 'Failed to load vehicle details'} 
          onRetry={() => refetch()} 
        />
      </div>
    );
  }

  if (!vehicle) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-6">
        <ErrorMessage 
          error="Vehicle not found" 
          onRetry={handleBack} 
        />
      </div>
    );
  }

  return <VehicleMaintenance vehicle={vehicle} onBack={handleBack} />;
};