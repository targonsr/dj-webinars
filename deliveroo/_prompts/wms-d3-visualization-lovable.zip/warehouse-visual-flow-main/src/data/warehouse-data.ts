import { WarehouseStructureGenerator } from "@/lib/warehouse-structure-generator";
import { WarehouseStructure } from "@/lib/warehouse.types";

// Export the warehouse structure from the generator for backward compatibility
export const warehouseData: WarehouseStructure = new WarehouseStructureGenerator().generateWarehouseStructure(30, 12);
