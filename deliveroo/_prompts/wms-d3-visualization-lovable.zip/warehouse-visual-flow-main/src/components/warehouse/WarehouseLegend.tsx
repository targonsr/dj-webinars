
import { WarehouseStructure } from "@/lib/warehouse.types";

const Colors = {
  tile: {
    rack: [
      '#E53E3E', '#38A169', '#3182CE', '#805AD5', '#D69E2E', '#DD6B20', '#319795', '#C53030'
    ]
  }
};

function zoneIdToIndex(zoneId: string | undefined): number {
  if (!zoneId) return 0;
  let index = 0;
  for (let i = 0; i < zoneId.length; i++) {
    index *= 26;
    index += zoneId.charCodeAt(i) - 65 + 1;
  }
  return index - 1;
}

interface WarehouseLegendProps {
  warehouseData: WarehouseStructure;
  onZoneHover: (zoneId: string | null) => void;
  selectedZone: string | null;
}

export const WarehouseLegend = ({ warehouseData, onZoneHover }: WarehouseLegendProps) => {
  const zoneEntries = Object.entries(warehouseData.zones);

  return (
    <div className="flex flex-wrap items-center gap-4">
      <span className="text-sm font-medium text-gray-700">Zones:</span>
      {zoneEntries.map(([zoneId, zoneInfo]) => (
        <div
          key={zoneId}
          className="flex items-center gap-2 cursor-pointer hover:opacity-80 transition-opacity"
          onMouseEnter={() => onZoneHover(zoneId)}
          onMouseLeave={() => onZoneHover(null)}
        >
          <div
            className="w-4 h-4 rounded border border-gray-300"
            style={{ backgroundColor: Colors.tile.rack[zoneIdToIndex(zoneId) % Colors.tile.rack.length] }}
          />
          <span className="text-sm text-gray-700">Zone {zoneId}</span>
        </div>
      ))}
    </div>
  );
};
