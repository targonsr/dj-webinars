
import { Button } from "@/components/ui/button";
import { 
  BarChart3, 
  Package, 
  Users, 
  Settings, 
  Bell,
  FileText,
  TrendingUp,
  MapPin
} from "lucide-react";

export const WarehouseNavigation = () => {
  const navigationItems = [
    { icon: BarChart3, label: "Dashboard", active: true },
    { icon: Package, label: "Inventory" },
    { icon: MapPin, label: "Layout" },
    { icon: TrendingUp, label: "Analytics" },
    { icon: Users, label: "Staff" },
    { icon: FileText, label: "Reports" },
    { icon: Bell, label: "Alerts" },
    { icon: Settings, label: "Settings" }
  ];

  return (
    <div className="space-y-4">
      <div>
        <h3 className="text-lg font-semibold text-gray-900 mb-4">Navigation</h3>
        <div className="space-y-2">
          {navigationItems.map((item, index) => (
            <Button
              key={index}
              variant={item.active ? "default" : "ghost"}
              className={`w-full justify-start ${
                item.active ? "bg-blue-600 text-white" : "text-gray-700 hover:bg-gray-100"
              }`}
            >
              <item.icon className="h-4 w-4 mr-3" />
              {item.label}
            </Button>
          ))}
        </div>
      </div>

      <div className="pt-4 border-t border-gray-200">
        <div className="text-sm text-gray-600">
          <div className="mb-2">
            <div className="font-medium">Current Shift</div>
            <div className="text-xs">Day Shift (06:00-14:00)</div>
          </div>
          <div className="mb-2">
            <div className="font-medium">Active Workers</div>
            <div className="text-xs">24 on duty</div>
          </div>
          <div>
            <div className="font-medium">Utilization</div>
            <div className="text-xs">76% capacity</div>
          </div>
        </div>
      </div>
    </div>
  );
};
