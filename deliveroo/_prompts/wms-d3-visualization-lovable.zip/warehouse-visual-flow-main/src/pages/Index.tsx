
import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowRight, Truck } from "lucide-react";

const Index = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-slate-50">
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex items-center justify-center mb-6">
            <div className="p-3 bg-blue-600 rounded-xl">
              <Truck className="h-12 w-12 text-white" />
            </div>
          </div>
          <h1 className="text-5xl font-bold text-gray-900 mb-6">
            Warehouse Management
            <span className="text-blue-600"> System</span>
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Modern logistics warehouse management application with interactive visualization, 
            real-time analytics, and intuitive warehouse mapping for optimal space utilization.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-12">
          <Card className="hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-blue-600">Interactive Warehouse Map</CardTitle>
              <CardDescription>
                30×12 grid visualization with color-coded zones, interactive tooltips, and dynamic highlighting
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Real-time rack capacity monitoring</li>
                <li>• Dynamic dock status tracking</li>
                <li>• Zone-based color coding</li>
                <li>• Hover and click interactions</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-green-600">Smart Analytics</CardTitle>
              <CardDescription>
                Advanced analytics for space utilization, capacity planning, and operational efficiency
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Capacity utilization metrics</li>
                <li>• Zone performance analysis</li>
                <li>• Predictive space planning</li>
                <li>• Custom reporting tools</li>
              </ul>
            </CardContent>
          </Card>

          <Card className="hover:shadow-xl transition-all duration-300 border-0 shadow-lg">
            <CardHeader>
              <CardTitle className="text-purple-600">Framework Agnostic</CardTitle>
              <CardDescription>
                Built with D3.js and TypeScript for maximum portability and reusability across frameworks
              </CardDescription>
            </CardHeader>
            <CardContent>
              <ul className="space-y-2 text-sm text-gray-600">
                <li>• Pure D3.js visualization engine</li>
                <li>• TypeScript for type safety</li>
                <li>• React, Vue, Angular compatible</li>
                <li>• Modular architecture</li>
              </ul>
            </CardContent>
          </Card>
        </div>

        <div className="text-center">
          <Link to="/warehouse">
            <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 text-lg rounded-xl shadow-lg hover:shadow-xl transition-all duration-300">
              Launch Warehouse Dashboard
              <ArrowRight className="ml-2 h-5 w-5" />
            </Button>
          </Link>
        </div>
      </div>
    </div>
  );
};

export default Index;
