import { useEffect, useRef, useState } from "react";
import { renderWarehouse } from "@/lib/warehouse-visualization";
import { warehouseStructureGenerator } from "@/lib/warehouse-structure-generator";
import { WarehouseStructure } from "@/lib/warehouse.types";
import { WarehouseHeader } from "@/components/warehouse/WarehouseHeader";
import { WarehouseLegend } from "@/components/warehouse/WarehouseLegend";
import { WarehouseNavigation } from "@/components/warehouse/WarehouseNavigation";
import { Card } from "@/components/ui/card";
import { warehouseData } from "@/data/warehouse-data";

const strategyOptions = [
  { value: 'strategy1', label: 'Fades and shades' },
  { value: 'strategy2', label: 'Bars' },
  { value: 'strategy3', label: 'Grids' },
  { value: 'none', label: 'No strategy' },
];

const WarehouseDashboard = () => {
  const visualizationRef = useRef<HTMLDivElement>(null);
  const [selectedZone, setSelectedZone] = useState<string | null>(null);
  const [strategy, setStrategy] = useState<string>('strategy2');
  const warehouseStructure: WarehouseStructure = warehouseStructureGenerator.getWarehouseStructure();

  useEffect(() => {
    if (visualizationRef.current) {
      console.log("Initializing warehouse visualization...");
      renderWarehouse(visualizationRef.current, warehouseStructure, strategy);
    }
  }, [warehouseStructure, strategy]);

  const handleLegendHover = (zoneId: string | null) => {
    setSelectedZone(zoneId);
    const event = new CustomEvent('highlightZone', { 
      detail: { zoneId } 
    });
    window.dispatchEvent(event);
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <WarehouseHeader />
      
      <div className="container mx-auto px-4 py-6">
        <div className="grid lg:grid-cols-5 gap-6">
          {/* Navigation Sidebar */}
          <div className="lg:col-span-1">
            <Card className="p-6 shadow-lg border-0">
              <WarehouseNavigation />
            </Card>
          </div>

          {/* Main Content */}
          <div className="lg:col-span-4">
            {/* Warehouse Visualization */}
            <Card className="p-6 shadow-lg border-0">
              <div className="mb-4">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Warehouse Layout</h2>
                <p className="text-gray-600 mb-4">Interactive {warehouseData.width}×{warehouseData.height} grid visualization with real-time capacity monitoring</p>
                {/* Strategy Select */}
                <div className="mb-4">
                  <label htmlFor="strategy-select" className="block text-sm font-medium text-gray-700 mb-1">Rack Utilization Visualization Strategy</label>
                  <select
                    id="strategy-select"
                    className="border border-gray-300 rounded px-2 py-1 text-sm"
                    value={strategy}
                    onChange={e => setStrategy(e.target.value)}
                  >
                    {strategyOptions.map(opt => (
                      <option key={opt.value} value={opt.value}>{opt.label}</option>
                    ))}
                  </select>
                </div>
                {/* Compact Zone Legend */}
                <WarehouseLegend 
                  warehouseData={warehouseData}
                  onZoneHover={handleLegendHover}
                  selectedZone={selectedZone}
                />
              </div>
              
              <div 
                ref={visualizationRef}
                className="w-full overflow-x-auto border-2 border-gray-200 rounded-lg bg-white"
                style={{ minHeight: '500px' }}
              />
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default WarehouseDashboard;
