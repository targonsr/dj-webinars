<template>
  <div class="min-h-screen bg-gray-50 dark:bg-gray-900">
    <AppHeaderGuest />
    <main>
      <slot />
    </main>
    <AppFooter />
  </div>
</template>