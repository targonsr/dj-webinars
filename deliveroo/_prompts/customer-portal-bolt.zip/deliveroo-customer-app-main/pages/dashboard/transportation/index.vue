<template>
  <div>
    <div class="mb-8 flex items-center justify-between">
      <div>
        <h1 class="text-2xl font-bold text-gray-900 dark:text-white">
          Transportation Requests
        </h1>
        <p class="mt-1 text-sm text-gray-500 dark:text-gray-400">
          Manage your road transportation requests across Europe
        </p>
      </div>
      <NuxtLink
        to="/dashboard/transportation/new"
        class="btn-primary"
      >
        <PlusIcon class="w-5 h-5 mr-2" />
        New Request
      </NuxtLink>
    </div>

    <!-- Filters -->
    <div class="card p-6 mb-6">
      <div class="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Status
          </label>
          <select v-model="filters.status" class="input">
            <option value="">All Statuses</option>
            <option value="SUBMITTED">Submitted</option>
            <option value="IN_PROGRESS">In Progress</option>
            <option value="PICKUP_SCHEDULED">Pickup Scheduled</option>
            <option value="PICKED_UP">Picked Up</option>
            <option value="IN_TRANSIT">In Transit</option>
            <option value="DELIVERED">Delivered</option>
          </select>
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Service Type
          </label>
          <select v-model="filters.serviceType" class="input">
            <option value="">All Types</option>
            <option value="FULL_TRUCKLOAD">Full Truckload</option>
            <option value="LESS_THAN_TRUCKLOAD">Less Than Truckload</option>
            <option value="EXPRESS_DELIVERY">Express Delivery</option>
            <option value="OVERSIZED_CARGO">Oversized Cargo</option>
          </select>
        </div>
        
        <div>
          <label class="block text-sm font-medium text-gray-700 dark:text-gray-300 mb-2">
            Date Range
          </label>
          <input
            v-model="filters.dateFrom"
            type="date"
            class="input"
            placeholder="From date"
          />
        </div>
        
        <div class="flex items-end">
          <button
            @click="clearFilters"
            class="btn-outline w-full"
          >
            Clear Filters
          </button>
        </div>
      </div>
    </div>

    <!-- Loading State -->
    <div v-if="isLoading" class="card p-8 text-center">
      <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-primary-600 mx-auto mb-4"></div>
      <p class="text-gray-500 dark:text-gray-400">Loading transportation requests...</p>
    </div>

    <!-- Error State -->
    <div v-else-if="isError" class="card p-8 text-center">
      <div class="mx-auto flex items-center justify-center h-16 w-16 rounded-full bg-red-100 dark:bg-red-900 mb-4">
        <ExclamationTriangleIcon class="h-8 w-8 text-red-600 dark:text-red-400" />
      </div>
      <h3 class="text-lg font-medium text-gray-900 dark:text-white mb-2">
        Error Loading Requests
      </h3>
      <p class="text-gray-500 dark:text-gray-400 mb-4">
        There was a problem loading your transportation requests.
      </p>
      <button 
        @click="loadTransportationRequests" 
        class="btn-primary"
      >
        Try Again
      </button>
    </div>

    <!-- Requests Table -->
    <div v-else class="card overflow-hidden">
      <div class="overflow-x-auto">
        <table class="min-w-full divide-y divide-gray-200 dark:divide-gray-700">
          <thead class="bg-gray-50 dark:bg-gray-800">
            <tr>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Request
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Route
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Service Type
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Status
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Pickup Date
              </th>
              <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 dark:text-gray-400 uppercase tracking-wider">
                Actions
              </th>
            </tr>
          </thead>
          <tbody class="bg-white dark:bg-gray-900 divide-y divide-gray-200 dark:divide-gray-700">
            <tr
              v-for="request in requests"
              :key="request.id"
              class="hover:bg-gray-50 dark:hover:bg-gray-800"
            >
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm font-medium text-gray-900 dark:text-white">
                  {{ request.requestNumber }}
                </div>
                <div class="text-sm text-gray-500 dark:text-gray-400">
                  {{ request.trackingNumber || 'Not assigned' }}
                </div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <div class="text-sm text-gray-900 dark:text-white">
                  {{ request.pickupLocation.address.city }} → {{ request.deliveryLocation.address.city }}
                </div>
                <div class="text-sm text-gray-500 dark:text-gray-400">
                  {{ request.pickupLocation.address.country }} → {{ request.deliveryLocation.address.country }}
                </div>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <span class="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200">
                  {{ formatServiceType(request.serviceType) }}
                </span>
              </td>
              <td class="px-6 py-4 whitespace-nowrap">
                <span
                  :class="[
                    'inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium',
                    getStatusColor(request.status)
                  ]"
                >
                  {{ formatStatus(request.status) }}
                </span>
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900 dark:text-white">
                {{ formatDate(request.requestedPickupDate) }}
              </td>
              <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                <div class="flex space-x-3">
                  <NuxtLink
                    :to="`/dashboard/requests/transportation/${request.id}`"
                    class="flex items-center text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-200"
                  >
                    <EyeIcon class="w-5 h-5 mr-1" />
                    <span>View</span>
                  </NuxtLink>
                  <button
                    v-if="request.trackingNumber"
                    @click="trackShipment(request.trackingNumber)"
                    class="flex items-center text-gray-600 hover:text-gray-900 dark:text-gray-400 dark:hover:text-gray-200"
                  >
                    <MapPinIcon class="w-5 h-5 mr-1" />
                    <span>Track</span>
                  </button>
                </div>
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</template>

<script setup lang="ts">
import { 
  PlusIcon, 
  EyeIcon, 
  MapPinIcon,
  ExclamationTriangleIcon
} from '@heroicons/vue/24/outline'
import { transportationApi } from '~/api/transportation.api'
import type { TransportationRequest } from '~/model/transportation'

const filters = reactive({
  status: '',
  serviceType: '',
  dateFrom: ''
})

// Direct state management like dashboard
const requests = ref<TransportationRequest[]>([])
const isLoading = ref(false)
const isError = ref(false)

const loadTransportationRequests = async () => {
  isLoading.value = true
  isError.value = false
  
  try {
    requests.value = await transportationApi.getTransportationRequests(filters)
  } catch (error) {
    isError.value = true
    console.error('Error fetching transportation requests:', error)
  } finally {
    isLoading.value = false
  }
}

// Load requests on mount
onMounted(() => {
  loadTransportationRequests()
})

// Watch filters for changes
watch(filters, () => {
  loadTransportationRequests()
}, { deep: true })

const clearFilters = () => {
  filters.status = ''
  filters.serviceType = ''
  filters.dateFrom = ''
}

const formatServiceType = (type: string) => {
  return type.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase())
}

const formatStatus = (status: string) => {
  return status.replace(/_/g, ' ').toLowerCase().replace(/\b\w/g, l => l.toUpperCase())
}

const getStatusColor = (status: string) => {
  const colors = {
    'SUBMITTED': 'bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-200',
    'IN_PROGRESS': 'bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-200',
    'PICKUP_SCHEDULED': 'bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-200',
    'PICKED_UP': 'bg-cyan-100 text-cyan-800 dark:bg-cyan-900 dark:text-cyan-200',
    'IN_TRANSIT': 'bg-purple-100 text-purple-800 dark:bg-purple-900 dark:text-purple-200',
    'DELIVERED': 'bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-200'
  }
  return colors[status as keyof typeof colors] || 'bg-gray-100 text-gray-800 dark:bg-gray-900 dark:text-gray-200'
}

const formatDate = (date: Date) => {
  return new Intl.DateTimeFormat('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric'
  }).format(date)
}

const trackShipment = (trackingNumber: string) => {
  navigateTo(`/dashboard/tracking?number=${trackingNumber}`)
}

definePageMeta({
  layout: 'dashboard',
  middleware: 'auth'
})
</script>