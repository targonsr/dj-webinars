import { mockTransportationRequests } from '~/model/transportation/transportation.mocks'
import type { TransportationRequest } from '~/model/transportation'

export const transportationApi = {
  async getTransportationRequests(filters: any = {}): Promise<TransportationRequest[]> {
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 700))
    
    let filteredRequests = [...mockTransportationRequests]
    
    // Apply filters
    if (filters.status) {
      filteredRequests = filteredRequests.filter(req => req.status === filters.status)
    }
    if (filters.serviceType) {
      filteredRequests = filteredRequests.filter(req => req.serviceType === filters.serviceType)
    }
    if (filters.dateFrom) {
      filteredRequests = filteredRequests.filter(req => 
        new Date(req.requestedPickupDate) >= new Date(filters.dateFrom)
      )
    }
    
    return filteredRequests
  },

  async createTransportationRequest(data: any) {
    await new Promise(resolve => setTimeout(resolve, 2000))
    
    const requestNumber = `TR-${new Date().getFullYear()}-${String(Date.now()).slice(-6)}`
    
    return {
      id: requestNumber,
      requestNumber,
      ...data,
      status: 'SUBMITTED',
      createdAt: new Date(),
      updatedAt: new Date()
    }
  }
}