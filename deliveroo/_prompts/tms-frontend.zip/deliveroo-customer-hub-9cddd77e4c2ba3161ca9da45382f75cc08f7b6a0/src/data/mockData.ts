// TypeScript interfaces for mock data types
export interface Order {
  id: number;
  customer: string;
  status: 'Processing' | 'Shipped' | 'Delivered' | 'Canceled' | 'Returned';
  amount: string;
  date: string;
}

export interface Notification {
  id: number;
  type: 'success' | 'info' | 'message' | 'warning';
  message: string;
  time: string;
  icon: string;
}

export interface KPIs {
  ordersToday: number;
  revenue: number;
  completionRate: number;
  activeShipments: number;
}

export interface Shipment {
  id: string;
  origin: string;
  destination: string;
  status: 'In Transit' | 'Delivered' | 'Loading';
  driver: string;
  eta: string;
}

export interface Driver {
  id: string;
  name: string;
  status: 'Active' | 'Off Duty';
  currentLocation: string;
  rating: number;
  deliveries: number;
}

export interface Truck {
  id: string;
  model: string;
  driver: string;
  status: 'On Route' | 'Available' | 'Maintenance';
  capacity: string;
  location: string;
}

export interface Payment {
  id: string;
  amount: string;
  status: 'Paid' | 'Pending';
  date: string;
  method: 'Bank Transfer' | 'Credit Card' | 'Check';
  invoice: string;
}

export const mockOrders: Order[] = [
  { id: 1, customer: 'Jan Kowalski', status: 'Processing', amount: '$1,250', date: '2024-06-06' },
  { id: 2, customer: 'Anna Nowak', status: 'Shipped', amount: '$890', date: '2024-06-05' },
  { id: 3, customer: 'Piotr Wiśniewski', status: 'Delivered', amount: '$2,100', date: '2024-06-04' },
  { id: 4, customer: 'Magdalena Dąbrowska', status: 'Canceled', amount: '$450', date: '2024-06-03' },
  { id: 5, customer: 'Jakub Lewandowski', status: 'Returned', amount: '$1,600', date: '2024-06-02' },
  { id: 6, customer: 'Katarzyna Zielińska', status: 'Processing', amount: '$3,750', date: '2024-06-06' },
  { id: 7, customer: 'Tomasz Szymański', status: 'Shipped', amount: '$925', date: '2024-06-05' },
  { id: 8, customer: 'Monika Woźniak', status: 'Delivered', amount: '$1,340', date: '2024-06-04' },
  { id: 9, customer: 'Marcin Kozłowski', status: 'Processing', amount: '$2,680', date: '2024-06-03' },
  { id: 10, customer: 'Agnieszka Jankowska', status: 'Shipped', amount: '$815', date: '2024-06-02' },
  { id: 11, customer: 'Paweł Mazur', status: 'Delivered', amount: '$1,980', date: '2024-06-01' },
  { id: 12, customer: 'Beata Krawczyk', status: 'Canceled', amount: '$520', date: '2024-05-31' },
  { id: 13, customer: 'Krzysztof Adamczyk', status: 'Processing', amount: '$4,200', date: '2024-05-30' },
  { id: 14, customer: 'Ewa Jankowiak', status: 'Returned', amount: '$1,125', date: '2024-05-29' },
  { id: 15, customer: 'Bartosz Wójcik', status: 'Delivered', amount: '$2,850', date: '2024-05-28' },
];

export const mockNotifications: Notification[] = [
  { id: 1, type: 'success', message: 'Payment received', time: '2h', icon: '✅' },
  { id: 2, type: 'info', message: 'Order #12345 has been shipped', time: '5h', icon: '📦' },
  { id: 3, type: 'message', message: 'New message from Sarah Wilson', time: '8h', icon: '💬' },
  { id: 4, type: 'warning', message: '3 orders have delayed', time: '1d', icon: '⚠️' },
  { id: 5, type: 'success', message: 'Driver completed delivery', time: '3h', icon: '✅' },
  { id: 6, type: 'info', message: 'Truck TR005 maintenance scheduled', time: '6h', icon: '🔧' },
  { id: 7, type: 'message', message: 'Customer inquiry from John Doe', time: '12h', icon: '💬' },
  { id: 8, type: 'warning', message: 'Low fuel alert for truck TR002', time: '2d', icon: '⛽' },
  { id: 9, type: 'success', message: 'Route optimization completed', time: '4h', icon: '🗺️' },
  { id: 10, type: 'info', message: 'Weather alert for route I-95', time: '7h', icon: '🌧️' },
  { id: 11, type: 'message', message: 'Driver availability request', time: '1d', icon: '👤' },
  { id: 12, type: 'warning', message: 'Traffic delay on Route 101', time: '15h', icon: '🚗' },
];

export const mockKPIs: KPIs = {
  ordersToday: 32,
  revenue: 1825,
  completionRate: 96,
  activeShipments: 24,
};

export const mockShipments: Shipment[] = [
  { id: 'SH001', origin: 'Warsaw', destination: 'Krakow', status: 'In Transit', driver: 'Michał Kowalski', eta: '2024-06-08' },
  { id: 'SH002', origin: 'Gdansk', destination: 'Wroclaw', status: 'Delivered', driver: 'Anna Nowak', eta: '2024-06-06' },
  { id: 'SH003', origin: 'Poznan', destination: 'Katowice', status: 'Loading', driver: 'Piotr Wiśniewski', eta: '2024-06-09' },
  { id: 'SH004', origin: 'Lodz', destination: 'Szczecin', status: 'In Transit', driver: 'Magdalena Dąbrowska', eta: '2024-06-07' },
  { id: 'SH005', origin: 'Prague', destination: 'Bratislava', status: 'Loading', driver: 'Jakub Lewandowski', eta: '2024-06-10' },
  { id: 'SH006', origin: 'Budapest', destination: 'Vienna', status: 'In Transit', driver: 'Katarzyna Zielińska', eta: '2024-06-08' },
  { id: 'SH007', origin: 'Lublin', destination: 'Bydgoszcz', status: 'Delivered', driver: 'Tomasz Szymański', eta: '2024-06-05' },
  { id: 'SH008', origin: 'Rzeszow', destination: 'Torun', status: 'In Transit', driver: 'Monika Woźniak', eta: '2024-06-09' },
  { id: 'SH009', origin: 'Opole', destination: 'Olsztyn', status: 'Loading', driver: 'Marcin Kozłowski', eta: '2024-06-11' },
  { id: 'SH010', origin: 'Kielce', destination: 'Zabrze', status: 'In Transit', driver: 'Agnieszka Jankowska', eta: '2024-06-08' },
  { id: 'SH011', origin: 'Radom', destination: 'Gliwice', status: 'Delivered', driver: 'Paweł Mazur', eta: '2024-06-06' },
  { id: 'SH012', origin: 'Białystok', destination: 'Częstochowa', status: 'Loading', driver: 'Beata Krawczyk', eta: '2024-06-12' },
];

export const mockDrivers: Driver[] = [
  { id: 'DR001', name: 'Michał Kowalski', status: 'Active', currentLocation: 'Mazowieckie', rating: 4.8, deliveries: 145 },
  { id: 'DR002', name: 'Anna Nowak', status: 'Active', currentLocation: 'Małopolskie', rating: 4.9, deliveries: 203 },
  { id: 'DR003', name: 'Piotr Wiśniewski', status: 'Off Duty', currentLocation: 'Wielkopolskie', rating: 4.7, deliveries: 98 },
  { id: 'DR004', name: 'Magdalena Dąbrowska', status: 'Active', currentLocation: 'Dolnośląskie', rating: 4.6, deliveries: 156 },
  { id: 'DR005', name: 'Jakub Lewandowski', status: 'Off Duty', currentLocation: 'Śląskie', rating: 4.9, deliveries: 267 },
  { id: 'DR006', name: 'Katarzyna Zielińska', status: 'Active', currentLocation: 'Pomorskie', rating: 4.8, deliveries: 189 },
  { id: 'DR007', name: 'Tomasz Szymański', status: 'Active', currentLocation: 'Łódzkie', rating: 4.5, deliveries: 123 },
  { id: 'DR008', name: 'Monika Woźniak', status: 'Active', currentLocation: 'Lubelskie', rating: 4.7, deliveries: 178 },
  { id: 'DR009', name: 'Marcin Kozłowski', status: 'Off Duty', currentLocation: 'Kujawsko-pomorskie', rating: 4.6, deliveries: 134 },
  { id: 'DR010', name: 'Agnieszka Jankowska', status: 'Active', currentLocation: 'Zachodniopomorskie', rating: 4.8, deliveries: 198 },
  { id: 'DR011', name: 'Paweł Mazur', status: 'Active', currentLocation: 'Warmińsko-mazurskie', rating: 4.9, deliveries: 245 },
  { id: 'DR012', name: 'Beata Krawczyk', status: 'Off Duty', currentLocation: 'Podlaskie', rating: 4.7, deliveries: 167 },
];

export const mockTrucks: Truck[] = [
  { id: 'TR001', model: 'Volvo FH16', driver: 'Michał Kowalski', status: 'On Route', capacity: '40 ton', location: 'Mazowieckie' },
  { id: 'TR002', model: 'Mercedes Actros', driver: 'Anna Nowak', status: 'Available', capacity: '38 ton', location: 'Małopolskie' },
  { id: 'TR003', model: 'Scania R450', driver: 'Piotr Wiśniewski', status: 'Maintenance', capacity: '42 ton', location: 'Wielkopolskie' },
  { id: 'TR004', model: 'MAN TGX', driver: 'Magdalena Dąbrowska', status: 'On Route', capacity: '36 ton', location: 'Dolnośląskie' },
  { id: 'TR005', model: 'DAF XF', driver: 'Jakub Lewandowski', status: 'Available', capacity: '44 ton', location: 'Śląskie' },
  { id: 'TR006', model: 'Iveco Stralis', driver: 'Katarzyna Zielińska', status: 'On Route', capacity: '40 ton', location: 'Pomorskie' },
  { id: 'TR007', model: 'Renault T High', driver: 'Tomasz Szymański', status: 'Available', capacity: '35 ton', location: 'Łódzkie' },
  { id: 'TR008', model: 'Volvo FH', driver: 'Monika Woźniak', status: 'On Route', capacity: '41 ton', location: 'Lubelskie' },
  { id: 'TR009', model: 'Scania S500', driver: 'Marcin Kozłowski', status: 'Maintenance', capacity: '39 ton', location: 'Kujawsko-pomorskie' },
  { id: 'TR010', model: 'Mercedes Arocs', driver: 'Agnieszka Jankowska', status: 'On Route', capacity: '40 ton', location: 'Zachodniopomorskie' },
  { id: 'TR011', model: 'MAN TGS', driver: 'Paweł Mazur', status: 'Available', capacity: '43 ton', location: 'Warmińsko-mazurskie' },
  { id: 'TR012', model: 'DAF CF', driver: 'Beata Krawczyk', status: 'Maintenance', capacity: '37 ton', location: 'Podlaskie' },
];

export const mockPayments: Payment[] = [
  { id: 'PAY001', amount: '$2,500', status: 'Paid', date: '2024-06-06', method: 'Bank Transfer', invoice: 'INV-001' },
  { id: 'PAY002', amount: '$1,800', status: 'Pending', date: '2024-06-05', method: 'Credit Card', invoice: 'INV-002' },
  { id: 'PAY003', amount: '$3,200', status: 'Paid', date: '2024-06-04', method: 'Check', invoice: 'INV-003' },
  { id: 'PAY004', amount: '$4,750', status: 'Paid', date: '2024-06-03', method: 'Bank Transfer', invoice: 'INV-004' },
  { id: 'PAY005', amount: '$925', status: 'Pending', date: '2024-06-02', method: 'Credit Card', invoice: 'INV-005' },
  { id: 'PAY006', amount: '$1,340', status: 'Paid', date: '2024-06-01', method: 'Check', invoice: 'INV-006' },
  { id: 'PAY007', amount: '$6,200', status: 'Paid', date: '2024-05-31', method: 'Bank Transfer', invoice: 'INV-007' },
  { id: 'PAY008', amount: '$2,680', status: 'Pending', date: '2024-05-30', method: 'Credit Card', invoice: 'INV-008' },
  { id: 'PAY009', amount: '$815', status: 'Paid', date: '2024-05-29', method: 'Bank Transfer', invoice: 'INV-009' },
  { id: 'PAY010', amount: '$1,980', status: 'Pending', date: '2024-05-28', method: 'Check', invoice: 'INV-010' },
  { id: 'PAY011', amount: '$3,450', status: 'Paid', date: '2024-05-27', method: 'Credit Card', invoice: 'INV-011' },
  { id: 'PAY012', amount: '$5,125', status: 'Paid', date: '2024-05-26', method: 'Bank Transfer', invoice: 'INV-012' },
];
