
import { useQuery } from '@tanstack/react-query';
import { mockOrders, mockShipments, mockDrivers, mockTrucks, mockPayments, mockNotifications, mockKPIs } from '@/data/mockData';

// Simulate API delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export const useOrders = () => {
  return useQuery({
    queryKey: ['orders'],
    queryFn: async () => {
      await delay(500);
      return mockOrders;
    },
  });
};

export const useOrder = (id: string) => {
  return useQuery({
    queryKey: ['order', id],
    queryFn: async () => {
      await delay(300);
      return mockOrders.find(order => order.id.toString() === id);
    },
  });
};

export const useShipments = (filters?: { driver?: string; status?: string; location?: string }) => {
  return useQuery({
    queryKey: ['shipments', filters],
    queryFn: async () => {
      await delay(500);
      let filteredShipments = [...mockShipments];
      
      if (filters?.driver) {
        filteredShipments = filteredShipments.filter(s => 
          s.driver.toLowerCase().includes(filters.driver.toLowerCase())
        );
      }
      if (filters?.status) {
        filteredShipments = filteredShipments.filter(s => 
          s.status.toLowerCase().includes(filters.status.toLowerCase())
        );
      }
      if (filters?.location) {
        filteredShipments = filteredShipments.filter(s => 
          s.origin.toLowerCase().includes(filters.location.toLowerCase()) ||
          s.destination.toLowerCase().includes(filters.location.toLowerCase())
        );
      }
      
      return filteredShipments;
    },
  });
};

export const useShipment = (id: string) => {
  return useQuery({
    queryKey: ['shipment', id],
    queryFn: async () => {
      await delay(300);
      return mockShipments.find(shipment => shipment.id === id);
    },
  });
};

export const useDrivers = () => {
  return useQuery({
    queryKey: ['drivers'],
    queryFn: async () => {
      await delay(500);
      return mockDrivers;
    },
  });
};

export const useDriver = (id: string) => {
  return useQuery({
    queryKey: ['driver', id],
    queryFn: async () => {
      await delay(300);
      return mockDrivers.find(driver => driver.id === id);
    },
  });
};

export const useDriverShipments = (driverId: string) => {
  return useQuery({
    queryKey: ['driver-shipments', driverId],
    queryFn: async () => {
      await delay(300);
      const driver = mockDrivers.find(d => d.id === driverId);
      if (!driver) return [];
      return mockShipments.filter(s => s.driver === driver.name);
    },
  });
};

export const useTrucks = () => {
  return useQuery({
    queryKey: ['trucks'],
    queryFn: async () => {
      await delay(500);
      return mockTrucks;
    },
  });
};

export const usePayments = () => {
  return useQuery({
    queryKey: ['payments'],
    queryFn: async () => {
      await delay(500);
      return mockPayments;
    },
  });
};

export const useNotifications = () => {
  return useQuery({
    queryKey: ['notifications'],
    queryFn: async () => {
      await delay(200);
      return mockNotifications;
    },
  });
};

export const useKPIs = () => {
  return useQuery({
    queryKey: ['kpis'],
    queryFn: async () => {
      await delay(300);
      return mockKPIs;
    },
  });
};

export const useUrgentItems = () => {
  return useQuery({
    queryKey: ['urgent-items'],
    queryFn: async () => {
      await delay(400);
      return [
        { id: 1, type: 'delay', priority: 'high', message: 'Shipment SH001 delayed by 3 hours', action: 'Contact customer', assignee: 'Mike Johnson' },
        { id: 2, type: 'maintenance', priority: 'medium', message: 'Truck TR003 requires urgent maintenance', action: 'Schedule service', assignee: 'Sarah Lee' },
        { id: 3, type: 'payment', priority: 'high', message: 'Payment PAY002 overdue by 5 days', action: 'Follow up with client', assignee: 'David Chen' },
        { id: 4, type: 'driver', priority: 'low', message: 'Driver license expires in 30 days', action: 'Renewal reminder', assignee: 'Mike Johnson' },
      ];
    },
  });
};
