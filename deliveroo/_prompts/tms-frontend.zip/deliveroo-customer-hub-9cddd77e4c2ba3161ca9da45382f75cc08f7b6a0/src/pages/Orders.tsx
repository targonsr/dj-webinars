import React, { useState } from 'react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { useNavigate } from 'react-router-dom';
import { useOrders } from '@/hooks/useQueries';
import { MapPin, Clock, CheckCircle, AlertCircle } from 'lucide-react';

const Orders = () => {
  const navigate = useNavigate();
  const { data: orders = [], isLoading } = useOrders();
  const [activeTab, setActiveTab] = useState('overview');

  const getStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'processing': return 'bg-blue-100 text-blue-800';
      case 'shipped': return 'bg-green-100 text-green-800';
      case 'delivered': return 'bg-emerald-100 text-emerald-800';
      case 'canceled': return 'bg-red-100 text-red-800';
      case 'returned': return 'bg-orange-100 text-orange-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getColumnColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'processing': return 'bg-blue-50 border-blue-200';
      case 'shipped': return 'bg-yellow-50 border-yellow-200';
      case 'delivered': return 'bg-green-50 border-green-200';
      case 'canceled': return 'bg-red-50 border-red-200';
      default: return 'bg-gray-50 border-gray-200';
    }
  };

  const handleViewDetails = (orderId: number) => {
    navigate(`/orders/${orderId}`);
  };

  // Group orders by status for Kanban board
  const ordersByStatus = {
    processing: orders.filter(order => order.status.toLowerCase() === 'processing'),
    shipped: orders.filter(order => order.status.toLowerCase() === 'shipped'),
    delivered: orders.filter(order => order.status.toLowerCase() === 'delivered'),
    canceled: orders.filter(order => order.status.toLowerCase() === 'canceled'),
  };

  // Mock data for other tabs
  const incomingRequests = [
    {
      id: 'REQ001',
      customer: 'ABC Corp',
      address: '123 Main St, New York, NY',
      preferredDate: '2024-01-25',
      cargoType: 'Electronics',
      mass: '500 kg',
      volume: '2.5 m³',
      estimatedCost: '$450',
      estimatedTime: '4 hours',
      distance: '120 km',
      approved: false,
      conflicts: false,
    },
    {
      id: 'REQ002',
      customer: 'XYZ Ltd',
      address: '456 Oak Ave, Boston, MA',
      preferredDate: '2024-01-26',
      cargoType: 'Furniture',
      mass: '800 kg',
      volume: '5.0 m³',
      estimatedCost: '$650',
      estimatedTime: '6 hours',
      distance: '180 km',
      approved: true,
      conflicts: true,
    },
  ];

  const inTransitOrders = [
    {
      id: 'SH001',
      customer: 'Tech Solutions Inc',
      driver: 'Mike Johnson',
      elapsedTime: '2h 30m',
      distanceCovered: '85 km',
      totalDistance: '150 km',
      delay: false,
      estimatedDelay: null,
      status: 'On Schedule',
    },
    {
      id: 'SH002',
      customer: 'Global Trading Co',
      driver: 'Sarah Lee',
      elapsedTime: '4h 15m',
      distanceCovered: '120 km',
      totalDistance: '200 km',
      delay: true,
      estimatedDelay: '45 minutes',
      status: 'Delayed',
    },
  ];

  const deliveredOrders = [
    {
      id: 'DL001',
      customer: 'Retail Store',
      deliveredAt: '2024-01-20 14:30',
      recipient: 'John Smith',
      signatureLink: 'http://signatures.deliveroo.com/DL001',
      accepted: true,
    },
    {
      id: 'DL002',
      customer: 'Office Supplies Co',
      deliveredAt: '2024-01-21 09:15',
      recipient: 'Mary Johnson',
      signatureLink: 'http://signatures.deliveroo.com/DL002',
      accepted: true,
    },
  ];

  const paymentsData = [
    {
      id: 'PAY001',
      orderId: 'ORD001',
      amount: '$1,250',
      status: 'paid',
      dueDate: '2024-01-15',
      paymentDate: '2024-01-14',
      payer: 'ABC Corp',
      payee: 'Deliveroo LLC',
      currency: 'USD',
      transactionId: 'TXN123456',
      invoiceLink: 'http://invoicing.deliveroo.com/invoice/PAY001',
    },
    {
      id: 'PAY002',
      orderId: 'ORD002',
      amount: '$850',
      status: 'overdue',
      dueDate: '2024-01-10',
      paymentDate: null,
      payer: 'XYZ Ltd',
      payee: 'Deliveroo LLC',
      currency: 'USD',
      transactionId: null,
      invoiceLink: 'http://invoicing.deliveroo.com/invoice/PAY002',
    },
  ];

  const getPaymentStatusColor = (status: string) => {
    switch (status.toLowerCase()) {
      case 'paid': return 'bg-green-100 text-green-800';
      case 'pending': return 'bg-yellow-100 text-yellow-800';
      case 'overdue': return 'bg-red-100 text-red-800';
      case 'partially paid': return 'bg-orange-100 text-orange-800';
      case 'cancelled': return 'bg-gray-100 text-gray-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  if (isLoading) {
    return <div className="flex items-center justify-center h-64">Loading orders...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Transportation Orders</h1>
          <p className="text-gray-600">Manage your transportation orders and logistics</p>
        </div>
        <Button className="bg-blue-600 hover:bg-blue-700">
          Create New Order
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
        <TabsList className="grid w-full grid-cols-5">
          <TabsTrigger value="overview">Order Transportation Overview</TabsTrigger>
          <TabsTrigger value="incoming">Incoming Requests</TabsTrigger>
          <TabsTrigger value="transit">In Transit</TabsTrigger>
          <TabsTrigger value="delivered">Delivered</TabsTrigger>
          <TabsTrigger value="payments">Payments</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Order Transportation Overview</CardTitle>
              <CardDescription>Kanban board view of all orders by status</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                {Object.entries(ordersByStatus).map(([status, statusOrders]) => (
                  <div key={status} className={`p-4 rounded-lg border-2 ${getColumnColor(status)}`}>
                    <h3 className="font-semibold mb-4 capitalize flex items-center justify-between">
                      {status}
                      <span className="text-sm bg-white px-2 py-1 rounded-full">
                        {statusOrders.length}
                      </span>
                    </h3>
                    <div className="space-y-3">
                      {statusOrders.map((order) => (
                        <Card key={order.id} className="p-3 hover:shadow-md transition-shadow cursor-pointer" onClick={() => handleViewDetails(order.id)}>
                          <div className="space-y-2">
                            <div className="flex justify-between items-start">
                              <p className="font-medium text-sm">#{order.id.toString().padStart(5, '0')}</p>
                              <Badge className={getStatusColor(order.status)}>
                                {order.status}
                              </Badge>
                            </div>
                            <p className="text-sm font-medium">{order.customer}</p>
                            <p className="text-xs text-gray-600">{order.date}</p>
                            <p className="text-sm font-semibold text-blue-600">{order.amount}</p>
                          </div>
                        </Card>
                      ))}
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="incoming" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Incoming Requests</CardTitle>
              <CardDescription>Customer-submitted orders awaiting approval</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {incomingRequests.map((request) => (
                  <div key={request.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold text-lg">{request.id} - {request.customer}</h3>
                        <p className="text-gray-600 flex items-center">
                          <MapPin className="h-4 w-4 mr-1" />
                          {request.address}
                        </p>
                      </div>
                      <div className="flex space-x-2">
                        {request.approved && (
                          <Badge className="bg-green-100 text-green-800">
                            <CheckCircle className="h-3 w-3 mr-1" />
                            Approved
                          </Badge>
                        )}
                        {request.conflicts && (
                          <Badge className="bg-red-100 text-red-800">
                            <AlertCircle className="h-3 w-3 mr-1" />
                            Conflict
                          </Badge>
                        )}
                      </div>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-gray-600">Preferred Date</p>
                        <p className="font-medium">{request.preferredDate}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Cargo Type</p>
                        <p className="font-medium">{request.cargoType}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Mass/Volume</p>
                        <p className="font-medium">{request.mass} / {request.volume}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Estimated Cost</p>
                        <p className="font-medium text-green-600">{request.estimatedCost}</p>
                      </div>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex space-x-4 text-sm text-gray-600">
                        <span>⏱️ {request.estimatedTime}</span>
                        <span>📍 {request.distance}</span>
                        <a href="#" className="text-blue-600 hover:underline">View Route</a>
                      </div>
                      <div className="flex space-x-2">
                        <Button variant="outline" size="sm">Assign Driver</Button>
                        <Button size="sm" disabled={request.approved}>
                          {request.approved ? 'Approved' : 'Approve Order'}
                        </Button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="transit" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>In Transit</CardTitle>
              <CardDescription>Orders currently being transported</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {inTransitOrders.map((order) => (
                  <div key={order.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold text-lg">{order.id} - {order.customer}</h3>
                        <p className="text-gray-600">Driver: {order.driver}</p>
                      </div>
                      <Badge className={order.delay ? 'bg-red-100 text-red-800' : 'bg-green-100 text-green-800'}>
                        {order.status}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
                      <div>
                        <p className="text-sm text-gray-600">Elapsed Time</p>
                        <p className="font-medium">{order.elapsedTime}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Distance Covered</p>
                        <p className="font-medium">{order.distanceCovered} / {order.totalDistance}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Progress</p>
                        <div className="w-full bg-gray-200 rounded-full h-2">
                          <div 
                            className="bg-blue-600 h-2 rounded-full" 
                            style={{ 
                              width: `${(parseInt(order.distanceCovered) / parseInt(order.totalDistance)) * 100}%` 
                            }}
                          ></div>
                        </div>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Delay</p>
                        <p className="font-medium text-red-600">
                          {order.delay ? order.estimatedDelay : 'None'}
                        </p>
                      </div>
                    </div>

                    {order.delay && (
                      <div className="bg-red-50 p-3 rounded border-l-4 border-red-400">
                        <p className="text-sm text-red-800">
                          ⚠️ Delivery delayed by {order.estimatedDelay} due to traffic conditions
                        </p>
                      </div>
                    )}
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="delivered" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Delivered Orders</CardTitle>
              <CardDescription>Successfully completed deliveries</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {deliveredOrders.map((order) => (
                  <div key={order.id} className="border rounded-lg p-4">
                    <div className="flex justify-between items-start mb-3">
                      <div>
                        <h3 className="font-semibold text-lg">{order.id} - {order.customer}</h3>
                        <p className="text-gray-600">
                          <Clock className="h-4 w-4 inline mr-1" />
                          Delivered: {order.deliveredAt}
                        </p>
                      </div>
                      <Badge className="bg-green-100 text-green-800">
                        <CheckCircle className="h-3 w-3 mr-1" />
                        Delivered
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                      <div>
                        <p className="text-sm text-gray-600">Recipient</p>
                        <p className="font-medium">{order.recipient}</p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Acceptance</p>
                        <p className="font-medium text-green-600">
                          {order.accepted ? 'Accepted' : 'Pending'}
                        </p>
                      </div>
                      <div>
                        <p className="text-sm text-gray-600">Digital Signature</p>
                        <a 
                          href={order.signatureLink} 
                          target="_blank" 
                          rel="noopener noreferrer"
                          className="text-blue-600 hover:underline"
                        >
                          View Signature
                        </a>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="payments" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Payments</CardTitle>
              <CardDescription>Invoice and payment tracking</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left py-3 px-4 font-medium text-gray-500">Payment ID</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-500">Order</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-500">Amount</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-500">Status</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-500">Due Date</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-500">Payer</th>
                      <th className="text-left py-3 px-4 font-medium text-gray-500">Invoice</th>
                    </tr>
                  </thead>
                  <tbody>
                    {paymentsData.map((payment) => (
                      <tr key={payment.id} className="border-b hover:bg-gray-50">
                        <td className="py-3 px-4 font-medium">{payment.id}</td>
                        <td className="py-3 px-4">{payment.orderId}</td>
                        <td className="py-3 px-4 font-semibold">{payment.amount}</td>
                        <td className="py-3 px-4">
                          <Badge className={getPaymentStatusColor(payment.status)}>
                            {payment.status}
                          </Badge>
                        </td>
                        <td className="py-3 px-4">{payment.dueDate}</td>
                        <td className="py-3 px-4">{payment.payer}</td>
                        <td className="py-3 px-4">
                          <a 
                            href={payment.invoiceLink} 
                            target="_blank" 
                            rel="noopener noreferrer"
                            className="text-blue-600 hover:underline"
                          >
                            View Invoice
                          </a>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Orders;
