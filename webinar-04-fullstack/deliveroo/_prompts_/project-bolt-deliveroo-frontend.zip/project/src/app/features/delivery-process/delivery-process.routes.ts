import { Routes } from '@angular/router';
import { DeliveryProcessComponent } from './delivery-process.component';

export const DELIVERY_PROCESS_ROUTES: Routes = [
  {
    path: '',
    component: DeliveryProcessComponent
  }
];